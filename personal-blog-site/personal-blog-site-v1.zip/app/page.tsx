import { getAllPosts } from "@/lib/posts"
import { BlogPostCard } from "@/components/blog-post-card"
import { Pagination } from "@/components/pagination"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Home",
  description: "Welcome to my personal blog where I share insights, stories, and experiences.",
}

const POSTS_PER_PAGE = 6

interface HomePageProps {
  searchParams: { page?: string }
}

export default async function HomePage({ searchParams }: HomePageProps) {
  const currentPage = Number(searchParams.page) || 1
  const allPosts = await getAllPosts()

  const totalPages = Math.ceil(allPosts.length / POSTS_PER_PAGE)
  const startIndex = (currentPage - 1) * POSTS_PER_PAGE
  const endIndex = startIndex + POSTS_PER_PAGE
  const currentPosts = allPosts.slice(startIndex, endIndex)

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <section className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          Welcome to My Blog
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Sharing insights, stories, and experiences in technology, life, and everything in between.
        </p>
      </section>

      {/* Blog Posts Grid */}
      <section>
        <h2 className="text-2xl font-semibold mb-8">Latest Posts</h2>
        {currentPosts.length > 0 ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {currentPosts.map((post) => (
                <BlogPostCard key={post.slug} post={post} />
              ))}
            </div>

            {totalPages > 1 && <Pagination currentPage={currentPage} totalPages={totalPages} basePath="/" />}
          </>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">No posts available yet. Check back soon!</p>
          </div>
        )}
      </section>
    </div>
  )
}
