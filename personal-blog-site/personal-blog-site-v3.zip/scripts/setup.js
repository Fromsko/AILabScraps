const { execSync } = require("child_process")
const path = require("path")

async function setup() {
  try {
    console.log("🚀 Setting up Personal Blog...")

    // Install dependencies
    console.log("📦 Installing dependencies...")
    execSync("npm install", { stdio: "inherit" })

    // Generate Prisma client
    console.log("🔧 Generating Prisma client...")
    execSync("npx prisma generate", { stdio: "inherit" })

    // Run database migrations
    console.log("🗄️ Setting up database...")
    execSync("npx prisma db push", { stdio: "inherit" })

    // Seed database
    console.log("🌱 Seeding database...")
    execSync("npx tsx lib/seed.ts", { stdio: "inherit" })

    // Migrate existing posts
    console.log("📚 Migrating posts...")
    execSync("npx tsx scripts/migrate-posts.ts", { stdio: "inherit" })

    console.log("✅ Setup completed successfully!")
    console.log("\n🎉 Your blog is ready!")
    console.log("\nNext steps:")
    console.log("1. Run: npm run dev")
    console.log("2. Visit: http://localhost:3000")
    console.log("3. Admin panel: http://localhost:3000/admin/login")
    console.log("4. Login with: admin / admin123")
  } catch (error) {
    console.error("❌ Setup failed:", error.message)
    process.exit(1)
  }
}

setup()
