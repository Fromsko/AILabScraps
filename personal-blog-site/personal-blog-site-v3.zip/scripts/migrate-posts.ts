import { prisma } from "../lib/prisma"
import { getAllPosts } from "../lib/posts-legacy"
import { slugify } from "../lib/utils"

export async function migratePosts() {
  try {
    console.log("📚 Starting post migration...")

    // Get categories and tags
    const categories = await prisma.category.findMany()
    const tags = await prisma.tag.findMany()

    const posts = await getAllPosts()

    for (const post of posts) {
      console.log(`📝 Migrating post: ${post.title}`)

      // Find or create categories for this post
      const postCategories = []
      for (const tagName of post.tags) {
        const category = categories.find(
          (c) => c.name.toLowerCase() === tagName.toLowerCase() || c.slug === slugify(tagName),
        )
        if (category) {
          postCategories.push(category.id)
        }
      }

      // Find or create tags for this post
      const postTags = []
      for (const tagName of post.tags) {
        let tag = tags.find((t) => t.name.toLowerCase() === tagName.toLowerCase() || t.slug === slugify(tagName))

        if (!tag) {
          tag = await prisma.tag.create({
            data: {
              name: tagName,
              slug: slugify(tagName),
            },
          })
          tags.push(tag)
        }
        postTags.push(tag.id)
      }

      // Create the post
      await prisma.post.upsert({
        where: { slug: post.slug },
        update: {
          title: post.title,
          content: post.content,
          excerpt: post.description,
          featuredImage: post.image,
          publishDate: new Date(post.date),
          status: "published",
          isFeatured: false, // You can manually set featured posts later
          readingTime: post.readingTime,
          categories: {
            deleteMany: {},
            create: postCategories.map((categoryId) => ({ categoryId })),
          },
          tags: {
            deleteMany: {},
            create: postTags.map((tagId) => ({ tagId })),
          },
        },
        create: {
          title: post.title,
          slug: post.slug,
          content: post.content,
          excerpt: post.description,
          featuredImage: post.image,
          publishDate: new Date(post.date),
          status: "published",
          isFeatured: false,
          readingTime: post.readingTime,
          categories: {
            create: postCategories.map((categoryId) => ({ categoryId })),
          },
          tags: {
            create: postTags.map((tagId) => ({ tagId })),
          },
        },
      })

      console.log(`✅ Migrated: ${post.title}`)
    }

    console.log("🎉 Post migration completed!")
  } catch (error) {
    console.error("❌ Post migration failed:", error)
    throw error
  }
}

// Run migration if called directly
if (require.main === module) {
  migratePosts()
    .then(() => {
      console.log("Migration completed")
      process.exit(0)
    })
    .catch((error) => {
      console.error("Migration failed:", error)
      process.exit(1)
    })
}
