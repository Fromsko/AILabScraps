import { z } from "zod"

// Blog Post Schema
export const BlogPostSchema = z.object({
  id: z.string().optional(),
  title: z.string().min(1, "Title is required").max(200),
  slug: z.string().min(1, "Slug is required"),
  content: z.string().min(1, "Content is required"),
  excerpt: z.string().max(500).optional(),
  featuredImage: z.string().url().optional().or(z.literal("")),
  publishDate: z.string().or(z.date()),
  status: z.enum(["draft", "published"]),
  isFeatured: z.boolean().default(false),
  categoryIds: z.array(z.string()).default([]),
  tagIds: z.array(z.string()).default([]),
})

// Category Schema
export const CategorySchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1, "Name is required").max(100),
  slug: z.string().min(1, "Slug is required"),
  color: z.string().optional(),
  icon: z.string().optional(),
})

// Tag Schema
export const TagSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1, "Name is required").max(100),
  slug: z.string().min(1, "Slug is required"),
})

// Site Config Schema
export const SiteConfigSchema = z.object({
  siteTitle: z.string().min(1, "Site title is required"),
  tagline: z.string().min(1, "Tagline is required"),
  authorName: z.string().min(1, "Author name is required"),
  authorBio: z.string().min(1, "Author bio is required"),
  authorAvatar: z.string().url().optional().or(z.literal("")),
  resumeContent: z.string().optional(),
  resumePdfUrl: z.string().url().optional().or(z.literal("")),
  socialLinks: z.record(z.string()).default({}),
  navLinks: z
    .array(
      z.object({
        name: z.string(),
        href: z.string(),
      }),
    )
    .default([]),
  aiAgentPersona: z.string().min(1, "AI agent persona is required"),
  aiAgentKnowledgeBase: z.string().default(""),
  aiAgentGreeting: z.string().min(1, "AI agent greeting is required"),
  aiAgentIconUrl: z.string().url().optional().or(z.literal("")),
  aiAgentVisible: z.boolean().default(true),
  postsPerPage: z.number().min(1).max(20).default(6),
  featuredPostsCount: z.number().min(1).max(10).default(3),
})

// AI Chat Schema
export const ChatMessageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string(),
  timestamp: z.date().optional(),
})

export const ChatRequestSchema = z.object({
  message: z.string().min(1, "Message is required"),
  context: z
    .object({
      currentPage: z.string().optional(),
      postSlug: z.string().optional(),
    })
    .optional(),
})

// Admin User Schema
export const AdminUserSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
})

export type BlogPost = z.infer<typeof BlogPostSchema>
export type Category = z.infer<typeof CategorySchema>
export type Tag = z.infer<typeof TagSchema>
export type SiteConfig = z.infer<typeof SiteConfigSchema>
export type ChatMessage = z.infer<typeof ChatMessageSchema>
export type ChatRequest = z.infer<typeof ChatRequestSchema>
export type AdminUser = z.infer<typeof AdminUserSchema>
