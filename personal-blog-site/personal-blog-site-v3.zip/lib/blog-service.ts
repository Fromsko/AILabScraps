import { prisma } from "./prisma"

export interface BlogPostWithRelations {
  id: string
  title: string
  slug: string
  content: string
  excerpt?: string
  featuredImage?: string
  publishDate: Date
  updateDate: Date
  status: string
  isFeatured: boolean
  authorName: string
  readingTime: number
  categories: Array<{
    id: string
    name: string
    slug: string
    color?: string
    icon?: string
  }>
  tags: Array<{
    id: string
    name: string
    slug: string
  }>
}

export async function getAllPublishedPosts(
  page = 1,
  limit = 6,
): Promise<{
  posts: BlogPostWithRelations[]
  totalPages: number
  currentPage: number
}> {
  const skip = (page - 1) * limit

  const [posts, totalCount] = await Promise.all([
    prisma.post.findMany({
      where: { status: "published" },
      include: {
        categories: { include: { category: true } },
        tags: { include: { tag: true } },
      },
      orderBy: { publishDate: "desc" },
      skip,
      take: limit,
    }),
    prisma.post.count({ where: { status: "published" } }),
  ])

  const transformedPosts = posts.map((post) => ({
    ...post,
    categories: post.categories.map((pc) => pc.category),
    tags: post.tags.map((pt) => pt.tag),
  }))

  return {
    posts: transformedPosts,
    totalPages: Math.ceil(totalCount / limit),
    currentPage: page,
  }
}

export async function getPostBySlug(slug: string): Promise<BlogPostWithRelations | null> {
  const post = await prisma.post.findUnique({
    where: { slug, status: "published" },
    include: {
      categories: { include: { category: true } },
      tags: { include: { tag: true } },
    },
  })

  if (!post) return null

  return {
    ...post,
    categories: post.categories.map((pc) => pc.category),
    tags: post.tags.map((pt) => pt.tag),
  }
}

export async function getFeaturedPosts(limit = 3): Promise<BlogPostWithRelations[]> {
  const posts = await prisma.post.findMany({
    where: { status: "published", isFeatured: true },
    include: {
      categories: { include: { category: true } },
      tags: { include: { tag: true } },
    },
    orderBy: { publishDate: "desc" },
    take: limit,
  })

  return posts.map((post) => ({
    ...post,
    categories: post.categories.map((pc) => pc.category),
    tags: post.tags.map((pt) => pt.tag),
  }))
}

export async function getRelatedPosts(postId: string, limit = 3): Promise<BlogPostWithRelations[]> {
  // Get current post categories and tags
  const currentPost = await prisma.post.findUnique({
    where: { id: postId },
    include: {
      categories: { include: { category: true } },
      tags: { include: { tag: true } },
    },
  })

  if (!currentPost) return []

  const categoryIds = currentPost.categories.map((pc) => pc.categoryId)
  const tagIds = currentPost.tags.map((pt) => pt.tagId)

  // Find posts with similar categories or tags
  const relatedPosts = await prisma.post.findMany({
    where: {
      AND: [
        { id: { not: postId } },
        { status: "published" },
        {
          OR: [
            { categories: { some: { categoryId: { in: categoryIds } } } },
            { tags: { some: { tagId: { in: tagIds } } } },
          ],
        },
      ],
    },
    include: {
      categories: { include: { category: true } },
      tags: { include: { tag: true } },
    },
    orderBy: { publishDate: "desc" },
    take: limit,
  })

  return relatedPosts.map((post) => ({
    ...post,
    categories: post.categories.map((pc) => pc.category),
    tags: post.tags.map((pt) => pt.tag),
  }))
}

export async function searchPosts(
  query: string,
  page = 1,
  limit = 6,
): Promise<{
  posts: BlogPostWithRelations[]
  totalPages: number
  currentPage: number
}> {
  const skip = (page - 1) * limit

  const [posts, totalCount] = await Promise.all([
    prisma.post.findMany({
      where: {
        AND: [
          { status: "published" },
          {
            OR: [
              { title: { contains: query, mode: "insensitive" } },
              { content: { contains: query, mode: "insensitive" } },
              { excerpt: { contains: query, mode: "insensitive" } },
            ],
          },
        ],
      },
      include: {
        categories: { include: { category: true } },
        tags: { include: { tag: true } },
      },
      orderBy: { publishDate: "desc" },
      skip,
      take: limit,
    }),
    prisma.post.count({
      where: {
        AND: [
          { status: "published" },
          {
            OR: [
              { title: { contains: query, mode: "insensitive" } },
              { content: { contains: query, mode: "insensitive" } },
              { excerpt: { contains: query, mode: "insensitive" } },
            ],
          },
        ],
      },
    }),
  ])

  const transformedPosts = posts.map((post) => ({
    ...post,
    categories: post.categories.map((pc) => pc.category),
    tags: post.tags.map((pt) => pt.tag),
  }))

  return {
    posts: transformedPosts,
    totalPages: Math.ceil(totalCount / limit),
    currentPage: page,
  }
}
