import { prisma } from "./prisma"
import { getAllPublishedPosts, getPostBySlug, getFeaturedPosts, getRelatedPosts, searchPosts } from "./blog-service"

// Re-export functions from blog-service for backward compatibility
export { getAllPublishedPosts as getAllPosts }
export { getPostBySlug }
export { getFeaturedPosts }
export { getRelatedPosts }
export { searchPosts }

// Additional utility functions
export async function getPostSlugs(): Promise<string[]> {
  try {
    const posts = await prisma.post.findMany({
      where: { status: "published" },
      select: { slug: true },
    })
    return posts.map((post) => post.slug)
  } catch (error) {
    console.error("Error reading post slugs:", error)
    return []
  }
}

export async function getAllCategories() {
  return prisma.category.findMany({
    orderBy: { name: "asc" },
  })
}

export async function getAllTags() {
  return prisma.tag.findMany({
    orderBy: { name: "asc" },
  })
}
