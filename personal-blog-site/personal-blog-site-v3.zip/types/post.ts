export interface Post {
  slug: string
  title: string
  date: string
  description: string
  image: string
  tags: string[]
  readingTime: number
  content: string
}

export interface PostFrontmatter {
  title: string
  slug: string
  date: string
  description: string
  image: string
  tags: string[]
}
