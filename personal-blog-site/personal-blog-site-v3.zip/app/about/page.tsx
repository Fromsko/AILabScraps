import Image from "next/image"
import Link from "next/link"
import { Mail, Github, Linkedin, Twitter } from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "About Me",
  description: "Learn more about me, my background, interests, and what drives my passion for writing and technology.",
}

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Section */}
        <div className="lg:col-span-1">
          <div className="sticky top-8">
            <div className="text-center mb-6">
              <Image
                src="/placeholder.svg?height=200&width=200"
                alt="Profile Picture"
                width={200}
                height={200}
                className="w-48 h-48 rounded-full mx-auto mb-4 object-cover shadow-lg"
              />
              <h1 className="text-2xl font-bold mb-2">Your Name</h1>
              <p className="text-muted-foreground">Full-Stack Developer & Writer</p>
            </div>

            {/* Social Links */}
            <div className="flex justify-center space-x-4 mb-6">
              <a
                href="mailto:your.email@example.com"
                className="p-2 rounded-full bg-secondary hover:bg-secondary/80 transition-colors"
                aria-label="Email"
              >
                <Mail className="w-5 h-5" />
              </a>
              <a
                href="https://github.com/yourusername"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-secondary hover:bg-secondary/80 transition-colors"
                aria-label="GitHub"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="https://linkedin.com/in/yourusername"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-secondary hover:bg-secondary/80 transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="https://twitter.com/yourusername"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-full bg-secondary hover:bg-secondary/80 transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="w-5 h-5" />
              </a>
            </div>

            <div className="text-center">
              <Link
                href="/contact"
                className="inline-flex items-center px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
              >
                <Mail className="w-4 h-4 mr-2" />
                Get in Touch
              </Link>
            </div>
          </div>
        </div>

        {/* Content Section */}
        <div className="lg:col-span-2">
          <div className="prose prose-lg max-w-none">
            <h2>Hello, I'm [Your Name]</h2>
            <p>
              Welcome to my corner of the internet! I'm a passionate full-stack developer and writer who loves exploring
              the intersection of technology, creativity, and human experience.
            </p>

            <h3>My Journey</h3>
            <p>
              My journey in technology began over [X] years ago when I wrote my first line of code. Since then, I've had
              the privilege of working with amazing teams, building products that impact thousands of users, and
              continuously learning new technologies.
            </p>

            <p>
              I specialize in modern web development, with expertise in React, Next.js, TypeScript, and cloud
              technologies. But beyond the technical skills, I'm passionate about creating user experiences that are
              both beautiful and functional.
            </p>

            <h3>What I Write About</h3>
            <p>
              On this blog, you'll find a mix of technical tutorials, personal reflections, and insights from my journey
              as a developer. I believe in sharing knowledge and experiences to help others grow in their own careers.
            </p>

            <ul>
              <li>Web development best practices and tutorials</li>
              <li>Career advice and personal growth</li>
              <li>Technology trends and industry insights</li>
              <li>Project showcases and case studies</li>
              <li>Life lessons and personal reflections</li>
            </ul>

            <h3>Beyond Code</h3>
            <p>
              When I'm not coding or writing, you can find me [your hobbies/interests]. I believe that diverse
              experiences outside of technology make us better developers and more well-rounded individuals.
            </p>

            <h3>Let's Connect</h3>
            <p>
              I love connecting with fellow developers, writers, and curious minds. Whether you want to discuss a
              project, share ideas, or just say hello, don't hesitate to reach out!
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
