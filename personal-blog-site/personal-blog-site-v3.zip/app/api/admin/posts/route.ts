import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { BlogPostSchema } from "@/lib/schemas"
import { verifyToken } from "@/lib/auth"

async function verifyAuth(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) throw new Error("Not authenticated")

  const decoded = verifyToken(token)
  if (!decoded) throw new Error("Invalid token")

  return decoded.userId
}

export async function GET(request: NextRequest) {
  try {
    await verifyAuth(request)

    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const status = searchParams.get("status")
    const skip = (page - 1) * limit

    const where = status ? { status } : {}

    const [posts, totalCount] = await Promise.all([
      prisma.post.findMany({
        where,
        include: {
          categories: { include: { category: true } },
          tags: { include: { tag: true } },
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit,
      }),
      prisma.post.count({ where }),
    ])

    const transformedPosts = posts.map((post) => ({
      ...post,
      categories: post.categories.map((pc) => pc.category),
      tags: post.tags.map((pt) => pt.tag),
    }))

    return NextResponse.json({
      posts: transformedPosts,
      totalPages: Math.ceil(totalCount / limit),
      currentPage: page,
    })
  } catch (error) {
    console.error("Get posts error:", error)
    return NextResponse.json({ error: "Failed to fetch posts" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    await verifyAuth(request)

    const body = await request.json()
    const validatedData = BlogPostSchema.parse(body)

    // Calculate reading time (rough estimate: 200 words per minute)
    const wordCount = validatedData.content.split(/\s+/).length
    const readingTime = Math.ceil(wordCount / 200)

    const post = await prisma.post.create({
      data: {
        title: validatedData.title,
        slug: validatedData.slug,
        content: validatedData.content,
        excerpt: validatedData.excerpt,
        featuredImage: validatedData.featuredImage,
        publishDate: new Date(validatedData.publishDate),
        status: validatedData.status,
        isFeatured: validatedData.isFeatured,
        readingTime,
        categories: {
          create: validatedData.categoryIds.map((categoryId) => ({
            categoryId,
          })),
        },
        tags: {
          create: validatedData.tagIds.map((tagId) => ({
            tagId,
          })),
        },
      },
      include: {
        categories: { include: { category: true } },
        tags: { include: { tag: true } },
      },
    })

    const transformedPost = {
      ...post,
      categories: post.categories.map((pc) => pc.category),
      tags: post.tags.map((pt) => pt.tag),
    }

    return NextResponse.json(transformedPost, { status: 201 })
  } catch (error) {
    console.error("Create post error:", error)
    return NextResponse.json({ error: "Failed to create post" }, { status: 400 })
  }
}
