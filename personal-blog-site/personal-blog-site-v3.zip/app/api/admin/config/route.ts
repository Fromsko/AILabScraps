import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { SiteConfigSchema } from "@/lib/schemas"
import { verifyToken } from "@/lib/auth"

async function verifyAuth(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) throw new Error("Not authenticated")

  const decoded = verifyToken(token)
  if (!decoded) throw new Error("Invalid token")

  return decoded.userId
}

export async function GET(request: NextRequest) {
  try {
    await verifyAuth(request)

    let config = await prisma.siteConfig.findUnique({
      where: { id: "main" },
    })

    if (!config) {
      // Create default config if none exists
      config = await prisma.siteConfig.create({
        data: {
          id: "main",
          siteTitle: "Personal Blog",
          tagline: "Insights & Stories",
          authorName: "Blog Author",
          authorBio: "Welcome to my blog!",
        },
      })
    }

    // Parse JSON fields
    const parsedConfig = {
      ...config,
      socialLinks: JSON.parse(config.socialLinks),
      navLinks: JSON.parse(config.navLinks),
    }

    return NextResponse.json(parsedConfig)
  } catch (error) {
    console.error("Get config error:", error)
    return NextResponse.json({ error: "Failed to fetch configuration" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    await verifyAuth(request)

    const body = await request.json()
    const validatedData = SiteConfigSchema.parse(body)

    const config = await prisma.siteConfig.upsert({
      where: { id: "main" },
      update: {
        siteTitle: validatedData.siteTitle,
        tagline: validatedData.tagline,
        authorName: validatedData.authorName,
        authorBio: validatedData.authorBio,
        authorAvatar: validatedData.authorAvatar,
        resumeContent: validatedData.resumeContent,
        resumePdfUrl: validatedData.resumePdfUrl,
        socialLinks: JSON.stringify(validatedData.socialLinks),
        navLinks: JSON.stringify(validatedData.navLinks),
        aiAgentPersona: validatedData.aiAgentPersona,
        aiAgentKnowledgeBase: validatedData.aiAgentKnowledgeBase,
        aiAgentGreeting: validatedData.aiAgentGreeting,
        aiAgentIconUrl: validatedData.aiAgentIconUrl,
        aiAgentVisible: validatedData.aiAgentVisible,
        postsPerPage: validatedData.postsPerPage,
        featuredPostsCount: validatedData.featuredPostsCount,
      },
      create: {
        id: "main",
        siteTitle: validatedData.siteTitle,
        tagline: validatedData.tagline,
        authorName: validatedData.authorName,
        authorBio: validatedData.authorBio,
        authorAvatar: validatedData.authorAvatar,
        resumeContent: validatedData.resumeContent,
        resumePdfUrl: validatedData.resumePdfUrl,
        socialLinks: JSON.stringify(validatedData.socialLinks),
        navLinks: JSON.stringify(validatedData.navLinks),
        aiAgentPersona: validatedData.aiAgentPersona,
        aiAgentKnowledgeBase: validatedData.aiAgentKnowledgeBase,
        aiAgentGreeting: validatedData.aiAgentGreeting,
        aiAgentIconUrl: validatedData.aiAgentIconUrl,
        aiAgentVisible: validatedData.aiAgentVisible,
        postsPerPage: validatedData.postsPerPage,
        featuredPostsCount: validatedData.featuredPostsCount,
      },
    })

    // Parse JSON fields for response
    const parsedConfig = {
      ...config,
      socialLinks: JSON.parse(config.socialLinks),
      navLinks: JSON.parse(config.navLinks),
    }

    return NextResponse.json(parsedConfig)
  } catch (error) {
    console.error("Update config error:", error)
    return NextResponse.json({ error: "Failed to update configuration" }, { status: 400 })
  }
}
