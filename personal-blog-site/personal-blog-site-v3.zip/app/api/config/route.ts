import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET() {
  try {
    const config = await prisma.siteConfig.findUnique({
      where: { id: "main" },
    })

    if (!config) {
      // Return default config if none exists
      return NextResponse.json({
        siteTitle: "Personal Blog",
        tagline: "Insights & Stories",
        authorName: "Blog Author",
        authorBio: "Welcome to my blog!",
        socialLinks: {},
        navLinks: [],
        aiAgentVisible: true,
        aiAgentGreeting: "Hi! How can I help you today?",
      })
    }

    // Parse JSON fields and return only public fields
    const publicConfig = {
      siteTitle: config.siteTitle,
      tagline: config.tagline,
      authorName: config.authorName,
      authorBio: config.authorBio,
      authorAvatar: config.authorAvatar,
      resumeContent: config.resumeContent,
      resumePdfUrl: config.resumePdfUrl,
      socialLinks: JSON.parse(config.socialLinks),
      navLinks: JSON.parse(config.navLinks),
      aiAgentVisible: config.aiAgentVisible,
      aiAgentGreeting: config.aiAgentGreeting,
      aiAgentIconUrl: config.aiAgentIconUrl,
      postsPerPage: config.postsPerPage,
      featuredPostsCount: config.featuredPostsCount,
    }

    return NextResponse.json(publicConfig)
  } catch (error) {
    console.error("Get public config error:", error)
    return NextResponse.json({ error: "Failed to fetch configuration" }, { status: 500 })
  }
}
