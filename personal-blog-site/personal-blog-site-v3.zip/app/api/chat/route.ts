import { type NextRequest, NextResponse } from "next/server"
import { openai } from "@ai-sdk/openai"
import { streamText, tool } from "ai"
import { z } from "zod"
import { prisma } from "@/lib/prisma"
import { ChatRequestSchema } from "@/lib/schemas"

// Tool for getting blog posts
const getPostsTool = tool({
  description: "Get blog posts from the database",
  parameters: z.object({
    limit: z.number().min(1).max(10).default(5),
    featured: z.boolean().optional(),
  }),
  execute: async ({ limit, featured }) => {
    const posts = await prisma.post.findMany({
      where: {
        status: "published",
        ...(featured ? { isFeatured: true } : {}),
      },
      select: {
        title: true,
        slug: true,
        excerpt: true,
        publishDate: true,
      },
      orderBy: { publishDate: "desc" },
      take: limit,
    })

    return {
      posts: posts.map((post) => ({
        title: post.title,
        slug: post.slug,
        excerpt: post.excerpt,
        publishDate: post.publishDate.toISOString().split("T")[0],
        url: `/blog/${post.slug}`,
      })),
    }
  },
})

// Tool for searching posts
const searchPostsTool = tool({
  description: "Search for blog posts by title or content",
  parameters: z.object({
    query: z.string().min(1),
    limit: z.number().min(1).max(5).default(3),
  }),
  execute: async ({ query, limit }) => {
    const posts = await prisma.post.findMany({
      where: {
        status: "published",
        OR: [
          { title: { contains: query, mode: "insensitive" } },
          { content: { contains: query, mode: "insensitive" } },
          { excerpt: { contains: query, mode: "insensitive" } },
        ],
      },
      select: {
        title: true,
        slug: true,
        excerpt: true,
        publishDate: true,
      },
      orderBy: { publishDate: "desc" },
      take: limit,
    })

    return {
      posts: posts.map((post) => ({
        title: post.title,
        slug: post.slug,
        excerpt: post.excerpt,
        publishDate: post.publishDate.toISOString().split("T")[0],
        url: `/blog/${post.slug}`,
      })),
    }
  },
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { message, context } = ChatRequestSchema.parse(body)

    // Get site configuration for AI agent settings
    const siteConfig = await prisma.siteConfig.findUnique({
      where: { id: "main" },
    })

    if (!siteConfig?.aiAgentVisible) {
      return NextResponse.json({ error: "AI agent is currently disabled" }, { status: 503 })
    }

    // Get current page context if available
    let currentPageContext = ""
    if (context?.postSlug) {
      const post = await prisma.post.findUnique({
        where: { slug: context.postSlug, status: "published" },
        select: {
          title: true,
          excerpt: true,
          content: true,
        },
      })

      if (post) {
        currentPageContext = `\n\nCurrent page context: The user is viewing the blog post "${post.title}". Post summary: ${post.excerpt || post.content.slice(0, 200) + "..."}`
      }
    }

    // Construct system prompt using PromptX principles
    const systemPrompt = `You are a helpful AI assistant for a personal blog website. Your persona: ${siteConfig.aiAgentPersona}

ROLE: Blog Assistant & Knowledge Guide
CONSTRAINTS:
- Be conversational, friendly, and helpful
- Answer questions about the blog, its content, and the author
- Use the provided knowledge base and tools to give accurate information
- If you don't know something, say so honestly
- Keep responses concise but informative
- Use markdown formatting for better readability

KNOWLEDGE BASE:
${siteConfig.aiAgentKnowledgeBase}

CAPABILITIES:
- Answer questions about blog posts and content
- Search for specific topics in the blog
- Provide information about the author
- Help users navigate the site
- Share insights from the knowledge base${currentPageContext}

Remember to be helpful while staying within your knowledge domain.`

    const result = streamText({
      model: openai("gpt-4o-mini"),
      system: systemPrompt,
      messages: [{ role: "user", content: message }],
      tools: {
        getPosts: getPostsTool,
        searchPosts: searchPostsTool,
      },
      maxToolRoundtrips: 2,
    })

    return result.toDataStreamResponse()
  } catch (error) {
    console.error("Chat API error:", error)
    return NextResponse.json({ error: "Failed to process chat message" }, { status: 500 })
  }
}
