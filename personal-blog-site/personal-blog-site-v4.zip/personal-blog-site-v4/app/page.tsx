import { BlogPostCard } from "@/components/blog-post-card"
import { Pagination } from "@/components/pagination"
import { getAllPublishedPosts, getFeaturedPosts } from "@/lib/blog-service"
import { getDataAccess } from "@/lib/data/data-access-factory"
import type { Metadata } from "next"

export async function generateMetadata(): Promise<Metadata> {
  let config
  try {
    const dataAccess = getDataAccess()
    config = await dataAccess.siteConfig.get()
  } catch (error) {
    console.error("Failed to load site config:", error)
  }

  return {
    title: "Home",
    description:
      config?.tagline ||
      "Welcome to my personal blog where I share insights, stories, and experiences.",
  }
}

interface HomePageProps {
  searchParams: { page?: string }
}

export default async function HomePage({ searchParams }: HomePageProps) {
  const resolvedParams = await searchParams
  const currentPage = Number(resolvedParams.page)
  // 加载站点配置
  let config
  try {
    const dataAccess = getDataAccess()
    config = await dataAccess.siteConfig.get()
  } catch (error) {
    console.error("Failed to load site config:", error)
  }

  const postsPerPage = config?.postsPerPage || 6
  const featuredPostsCount = config?.featuredPostsCount || 3

  const [{ posts: allPosts, totalPages }, featuredPosts] = await Promise.all([
    getAllPublishedPosts(currentPage, postsPerPage),
    getFeaturedPosts(featuredPostsCount),
  ])

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <section className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          {config?.siteTitle || "Welcome to My Blog"}
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          {config?.tagline ||
            "Sharing insights, stories, and experiences in technology, life, and everything in between."}
        </p>
      </section>

      {/* Featured Posts */}
      {featuredPosts.length > 0 && (
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-8">Featured Posts</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredPosts.map((post) => (
              <BlogPostCard key={post.slug} post={post} />
            ))}
          </div>
        </section>
      )}

      {/* Latest Posts */}
      <section>
        <h2 className="text-2xl font-semibold mb-8">Latest Posts</h2>
        {allPosts.length > 0 ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {allPosts.map((post) => (
                <BlogPostCard key={post.slug} post={post} />
              ))}
            </div>

            {totalPages > 1 && (
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                basePath="/"
              />
            )}
          </>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">
              No posts available yet. Check back soon!
            </p>
          </div>
        )}
      </section>
    </div>
  )
}
