import { type NextRequest, NextResponse } from "next/server"
import { getDataAccess } from "@/lib/data/data-access-factory"
import { BlogPostSchema } from "@/lib/schemas"
import { verifyToken } from "@/lib/auth"

async function verifyAuth(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) throw new Error("Not authenticated")

  const decoded = verifyToken(token)
  if (!decoded) throw new Error("Invalid token")

  return decoded.userId
}

export async function GET(request: NextRequest) {
  try {
    await verifyAuth(request)

    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const status = searchParams.get("status") || undefined

    const dataAccess = getDataAccess()
    const result = await dataAccess.posts.findAll(page, limit, status)

    // 获取分类和标签信息
    const [categories, tags] = await Promise.all([dataAccess.categories.findAll(), dataAccess.tags.findAll()])

    const postsWithRelations = result.items.map((post) => ({
      ...post,
      categories: post.categoryIds.map((id) => categories.find((c) => c.id === id)).filter(Boolean),
      tags: post.tagIds.map((id) => tags.find((t) => t.id === id)).filter(Boolean),
    }))

    return NextResponse.json({
      posts: postsWithRelations,
      totalPages: result.totalPages,
      currentPage: result.currentPage,
    })
  } catch (error) {
    console.error("Get posts error:", error)
    return NextResponse.json({ error: "Failed to fetch posts" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    await verifyAuth(request)

    const body = await request.json()
    const validatedData = BlogPostSchema.parse(body)

    // 计算阅读时间
    const wordCount = validatedData.content.split(/\s+/).length
    const readingTime = Math.ceil(wordCount / 200)

    const dataAccess = getDataAccess()
    const post = await dataAccess.posts.create({
      title: validatedData.title,
      slug: validatedData.slug,
      content: validatedData.content,
      excerpt: validatedData.excerpt,
      featuredImage: validatedData.featuredImage,
      publishDate: new Date(validatedData.publishDate),
      status: validatedData.status,
      isFeatured: validatedData.isFeatured,
      authorName: "Blog Author",
      readingTime,
      categoryIds: validatedData.categoryIds,
      tagIds: validatedData.tagIds,
    })

    // 获取分类和标签信息
    const [categories, tags] = await Promise.all([dataAccess.categories.findAll(), dataAccess.tags.findAll()])

    const postWithRelations = {
      ...post,
      categories: post.categoryIds.map((id) => categories.find((c) => c.id === id)).filter(Boolean),
      tags: post.tagIds.map((id) => tags.find((t) => t.id === id)).filter(Boolean),
    }

    return NextResponse.json(postWithRelations, { status: 201 })
  } catch (error) {
    console.error("Create post error:", error)
    return NextResponse.json({ error: "Failed to create post" }, { status: 400 })
  }
}
