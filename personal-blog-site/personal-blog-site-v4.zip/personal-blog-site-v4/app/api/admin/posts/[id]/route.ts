import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { BlogPostSchema } from "@/lib/schemas"
import { verifyToken } from "@/lib/auth"

async function verifyAuth(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) throw new Error("Not authenticated")

  const decoded = verifyToken(token)
  if (!decoded) throw new Error("Invalid token")

  return decoded.userId
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await verifyAuth(request)

    const post = await prisma.post.findUnique({
      where: { id: params.id },
      include: {
        categories: { include: { category: true } },
        tags: { include: { tag: true } },
      },
    })

    if (!post) {
      return NextResponse.json({ error: "Post not found" }, { status: 404 })
    }

    const transformedPost = {
      ...post,
      categories: post.categories.map((pc) => pc.category),
      tags: post.tags.map((pt) => pt.tag),
    }

    return NextResponse.json(transformedPost)
  } catch (error) {
    console.error("Get post error:", error)
    return NextResponse.json({ error: "Failed to fetch post" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await verifyAuth(request)

    const body = await request.json()
    const validatedData = BlogPostSchema.parse(body)

    // Calculate reading time
    const wordCount = validatedData.content.split(/\s+/).length
    const readingTime = Math.ceil(wordCount / 200)

    // Delete existing relations
    await prisma.postCategory.deleteMany({
      where: { postId: params.id },
    })
    await prisma.postTag.deleteMany({
      where: { postId: params.id },
    })

    const post = await prisma.post.update({
      where: { id: params.id },
      data: {
        title: validatedData.title,
        slug: validatedData.slug,
        content: validatedData.content,
        excerpt: validatedData.excerpt,
        featuredImage: validatedData.featuredImage,
        publishDate: new Date(validatedData.publishDate),
        status: validatedData.status,
        isFeatured: validatedData.isFeatured,
        readingTime,
        categories: {
          create: validatedData.categoryIds.map((categoryId) => ({
            categoryId,
          })),
        },
        tags: {
          create: validatedData.tagIds.map((tagId) => ({
            tagId,
          })),
        },
      },
      include: {
        categories: { include: { category: true } },
        tags: { include: { tag: true } },
      },
    })

    const transformedPost = {
      ...post,
      categories: post.categories.map((pc) => pc.category),
      tags: post.tags.map((pt) => pt.tag),
    }

    return NextResponse.json(transformedPost)
  } catch (error) {
    console.error("Update post error:", error)
    return NextResponse.json({ error: "Failed to update post" }, { status: 400 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await verifyAuth(request)

    await prisma.post.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Delete post error:", error)
    return NextResponse.json({ error: "Failed to delete post" }, { status: 500 })
  }
}
