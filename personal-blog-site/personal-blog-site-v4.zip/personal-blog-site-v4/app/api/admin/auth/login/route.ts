import { authenticateAdmin, createAdminUser, generateToken } from "@/lib/auth"
import { AdminUserSchema } from "@/lib/schemas"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const validatedData = AdminUserSchema.parse(body)

    console.log(validatedData)

    const mock = await createAdminUser(
      validatedData.username,
      validatedData.password
    )

    console.log(mock)

    const user = await authenticateAdmin(
      validatedData.username,
      validatedData.password
    )
    if (!user) {
      return NextResponse.json(
        { error: "Invalid credentials" },
        { status: 401 }
      )
    }

    const token = generateToken(user.id)

    const response = NextResponse.json({
      success: true,
      user: { id: user.id, username: user.username, role: user.role },
    })

    // Set HTTP-only cookie
    response.cookies.set("admin-token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    })

    return response
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Invalid request data" }, { status: 400 })
  }
}
