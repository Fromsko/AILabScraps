import { NextResponse } from "next/server"
import { getDataAccess } from "@/lib/data/data-access-factory"

export async function GET() {
  try {
    const dataAccess = getDataAccess()
    const config = await dataAccess.siteConfig.get()

    // 返回公开配置
    const publicConfig = {
      siteTitle: config.siteTitle,
      tagline: config.tagline,
      authorName: config.authorName,
      authorBio: config.authorBio,
      authorAvatar: config.authorAvatar,
      resumeContent: config.resumeContent,
      resumePdfUrl: config.resumePdfUrl,
      socialLinks: config.socialLinks,
      navLinks: config.navLinks,
      aiAgentVisible: config.aiAgentVisible,
      aiAgentGreeting: config.aiAgentGreeting,
      aiAgentIconUrl: config.aiAgentIconUrl,
      postsPerPage: config.postsPerPage,
      featuredPostsCount: config.featuredPostsCount,
    }

    return NextResponse.json(publicConfig)
  } catch (error) {
    console.error("Get public config error:", error)
    return NextResponse.json({ error: "Failed to fetch configuration" }, { status: 500 })
  }
}
