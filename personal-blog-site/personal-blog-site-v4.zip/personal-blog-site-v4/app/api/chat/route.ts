import { getDataAccess } from "@/lib/data/data-access-factory"
import { ChatRequestSchema } from "@/lib/schemas"
import { openai } from "@ai-sdk/openai"
import { streamText, tool } from "ai"
import { type NextRequest, NextResponse } from "next/server"
import { z } from "zod"

// 获取博客文章的工具
const getPostsTool = tool({
  description: "Get blog posts from the database",
  parameters: z.object({
    limit: z.number().min(1).max(10).default(5),
    featured: z.boolean().optional(),
  }),
  execute: async ({ limit, featured }) => {
    const dataAccess = getDataAccess()

    let posts
    if (featured) {
      posts = await dataAccess.posts.findFeatured(limit)
    } else {
      const result = await dataAccess.posts.findAll(1, limit, "published")
      posts = result.items
    }

    return {
      posts: posts.map((post) => ({
        title: post.title,
        slug: post.slug,
        excerpt: post.excerpt,
        publishDate: post.publishDate.toISOString().split("T")[0],
        url: `/blog/${post.slug}`,
      })),
    }
  },
})

// 搜索文章的工具
const searchPostsTool = tool({
  description: "Search for blog posts by title or content",
  parameters: z.object({
    query: z.string().min(1),
    limit: z.number().min(1).max(5).default(3),
  }),
  execute: async ({ query, limit }) => {
    const dataAccess = getDataAccess()
    const result = await dataAccess.posts.search(query, 1, limit)

    return {
      posts: result.items.map((post) => ({
        title: post.title,
        slug: post.slug,
        excerpt: post.excerpt,
        publishDate: post.publishDate.toISOString().split("T")[0],
        url: `/blog/${post.slug}`,
      })),
    }
  },
})

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { message, context } = ChatRequestSchema.parse(body)

    // 获取站点配置
    const dataAccess = getDataAccess()
    const siteConfig = await dataAccess.siteConfig.get()

    if (!siteConfig.aiAgentVisible) {
      return NextResponse.json(
        { error: "AI agent is currently disabled" },
        { status: 503 }
      )
    }

    // 获取当前页面上下文
    let currentPageContext = ""
    if (context?.postSlug) {
      const post = await dataAccess.posts.findBySlug(context.postSlug)

      if (post && post.status === "published") {
        currentPageContext = `\n\nCurrent page context: The user is viewing the blog post "${
          post.title
        }". Post summary: ${post.excerpt || post.content.slice(0, 200) + "..."}`
      }
    }

    // 构建系统提示
    const systemPrompt = `You are a helpful AI assistant for a personal blog website. Your persona: ${siteConfig.aiAgentPersona}

ROLE: Blog Assistant & Knowledge Guide
CONSTRAINTS:
- Be conversational, friendly, and helpful
- Answer questions about the blog, its content, and the author
- Use the provided knowledge base and tools to give accurate information
- If you don't know something, say so honestly
- Keep responses concise but informative
- Use markdown formatting for better readability

KNOWLEDGE BASE:
${siteConfig.aiAgentKnowledgeBase}

CAPABILITIES:
- Answer questions about blog posts and content
- Search for specific topics in the blog
- Provide information about the author
- Help users navigate the site
- Share insights from the knowledge base${currentPageContext}

Remember to be helpful while staying within your knowledge domain.`

    const result = streamText({
      model: openai("gpt-4o-mini"),
      system: systemPrompt,
      messages: [{ role: "user", content: message }],
      tools: {
        getPosts: getPostsTool,
        searchPosts: searchPostsTool,
      },
    })

    return result.toDataStreamResponse()
  } catch (error) {
    console.error("Chat API error:", error)
    return NextResponse.json(
      { error: "Failed to process chat message" },
      { status: 500 }
    )
  }
}
