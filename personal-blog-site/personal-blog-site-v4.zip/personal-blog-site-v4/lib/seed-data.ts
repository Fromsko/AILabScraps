import { getDataAccess } from "./data/data-access-factory"
import { hashPassword } from "./auth"

export async function seedData() {
  try {
    console.log("🌱 Initializing data...")

    const dataAccess = getDataAccess()

    // 创建管理员用户
    try {
      const existingAdmin = await dataAccess.adminUsers.findByUsername("admin")
      if (!existingAdmin) {
        const hashedPassword = await hashPassword("admin123")
        await dataAccess.adminUsers.create({
          username: "admin",
          passwordHash: hashedPassword,
          role: "admin",
        })
        console.log("✅ Admin user created")
      }
    } catch (error) {
      console.log("ℹ️ Admin user already exists")
    }

    // 创建示例分类
    const categories = [
      { name: "Web Development", slug: "web-development", color: "#3B82F6", icon: "💻" },
      { name: "React", slug: "react", color: "#61DAFB", icon: "⚛️" },
      { name: "Next.js", slug: "nextjs", color: "#000000", icon: "▲" },
      { name: "Career", slug: "career", color: "#10B981", icon: "🚀" },
      { name: "Tutorial", slug: "tutorial", color: "#F59E0B", icon: "📚" },
    ]

    const createdCategories = []
    for (const category of categories) {
      try {
        const existing = await dataAccess.categories.findBySlug(category.slug)
        if (!existing) {
          const created = await dataAccess.categories.create(category)
          createdCategories.push(created)
        } else {
          createdCategories.push(existing)
        }
      } catch (error) {
        console.log(`ℹ️ Category ${category.name} already exists`)
      }
    }
    console.log("✅ Categories created")

    // 创建示例标签
    const tags = [
      { name: "JavaScript", slug: "javascript" },
      { name: "TypeScript", slug: "typescript" },
      { name: "CSS", slug: "css" },
      { name: "Frontend", slug: "frontend" },
      { name: "Backend", slug: "backend" },
      { name: "Best Practices", slug: "best-practices" },
      { name: "Performance", slug: "performance" },
      { name: "Architecture", slug: "architecture" },
    ]

    const createdTags = []
    for (const tag of tags) {
      try {
        const existing = await dataAccess.tags.findBySlug(tag.slug)
        if (!existing) {
          const created = await dataAccess.tags.create(tag)
          createdTags.push(created)
        } else {
          createdTags.push(existing)
        }
      } catch (error) {
        console.log(`ℹ️ Tag ${tag.name} already exists`)
      }
    }
    console.log("✅ Tags created")

    // 迁移现有的 Markdown 文章
    await migrateMarkdownPosts(createdCategories, createdTags)

    console.log("🎉 Data initialization completed!")
  } catch (error) {
    console.error("❌ Data initialization failed:", error)
    throw error
  }
}

async function migrateMarkdownPosts(categories: any[], tags: any[]) {
  try {
    // 导入现有的文章数据
    const { getAllPosts } = await import("./posts")
    const posts = await getAllPosts()

    const dataAccess = getDataAccess()

    for (const post of posts) {
      try {
        const existing = await dataAccess.posts.findBySlug(post.slug)
        if (existing) continue

        // 匹配分类和标签
        const postCategoryIds = []
        const postTagIds = []

        for (const tagName of post.tags) {
          const category = categories.find(
            (c) => c.name.toLowerCase() === tagName.toLowerCase() || c.slug === tagName.toLowerCase(),
          )
          if (category) {
            postCategoryIds.push(category.id)
          }

          const tag = tags.find(
            (t) => t.name.toLowerCase() === tagName.toLowerCase() || t.slug === tagName.toLowerCase(),
          )
          if (tag) {
            postTagIds.push(tag.id)
          }
        }

        await dataAccess.posts.create({
          title: post.title,
          slug: post.slug,
          content: post.content,
          excerpt: post.description,
          featuredImage: post.image,
          publishDate: new Date(post.date),
          status: "published",
          isFeatured: false,
          authorName: "Blog Author",
          readingTime: post.readingTime,
          categoryIds: postCategoryIds,
          tagIds: postTagIds,
        })

        console.log(`✅ Migrated post: ${post.title}`)
      } catch (error) {
        console.log(`ℹ️ Post ${post.title} already exists or failed to migrate`)
      }
    }
  } catch (error) {
    console.log("ℹ️ No existing posts to migrate")
  }
}

// 如果直接运行此脚本
if (require.main === module) {
  seedData()
    .then(() => {
      console.log("Seeding completed")
      process.exit(0)
    })
    .catch((error) => {
      console.error("Seeding failed:", error)
      process.exit(1)
    })
}
