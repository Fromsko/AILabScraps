import { prisma } from "./prisma"
import { hashPassword } from "./auth"

export async function seedDatabase() {
  try {
    console.log("🌱 Seeding database...")

    // Create admin user if doesn't exist
    const existingAdmin = await prisma.adminUser.findUnique({
      where: { username: "admin" },
    })

    if (!existingAdmin) {
      const hashedPassword = await hashPassword("admin123")
      await prisma.adminUser.create({
        data: {
          username: "admin",
          passwordHash: hashedPassword,
          role: "admin",
        },
      })
      console.log("✅ Admin user created")
    }

    // Create default site config
    const existingConfig = await prisma.siteConfig.findUnique({
      where: { id: "main" },
    })

    if (!existingConfig) {
      await prisma.siteConfig.create({
        data: {
          id: "main",
          siteTitle: "Personal Blog - Insights & Stories",
          tagline: "Sharing insights, stories, and experiences in technology, life, and everything in between.",
          authorName: "Blog Author",
          authorBio:
            "Welcome to my personal blog where I share insights, stories, and experiences in technology, life, and everything in between.",
          socialLinks: JSON.stringify({
            github: "https://github.com/yourusername",
            linkedin: "https://linkedin.com/in/yourusername",
            twitter: "https://twitter.com/yourusername",
            email: "your.email@example.com",
          }),
          navLinks: JSON.stringify([
            { name: "Home", href: "/" },
            { name: "About", href: "/about" },
            { name: "Resume", href: "/resume" },
            { name: "Contact", href: "/contact" },
          ]),
          aiAgentPersona:
            "I am a helpful AI assistant for this personal blog. I can answer questions about the blog content, the author, and help you navigate the site. I have access to all published blog posts and can search for specific topics.",
          aiAgentKnowledgeBase: `About the Author:
- Full-stack developer with expertise in React, Next.js, TypeScript, and modern web technologies
- Passionate about clean code, user experience, and continuous learning
- Experience with cloud technologies and database design
- Enjoys writing about web development, career advice, and technology trends

Blog Topics:
- Web development tutorials and best practices
- Technology insights and industry trends
- Career advice for developers
- Personal growth and productivity tips
- Project showcases and case studies

Contact Information:
- Available for collaborations and interesting projects
- Open to mentoring and tech discussions
- Usually responds within 24 hours`,
          aiAgentGreeting:
            "Hi! I'm here to help you explore this blog and answer any questions about the content or the author. What would you like to know?",
        },
      })
      console.log("✅ Site configuration created")
    }

    // Create sample categories
    const categories = [
      { name: "Web Development", slug: "web-development", color: "#3B82F6", icon: "💻" },
      { name: "React", slug: "react", color: "#61DAFB", icon: "⚛️" },
      { name: "Next.js", slug: "nextjs", color: "#000000", icon: "▲" },
      { name: "Career", slug: "career", color: "#10B981", icon: "🚀" },
      { name: "Tutorial", slug: "tutorial", color: "#F59E0B", icon: "📚" },
    ]

    for (const category of categories) {
      await prisma.category.upsert({
        where: { slug: category.slug },
        update: {},
        create: category,
      })
    }
    console.log("✅ Categories created")

    // Create sample tags
    const tags = [
      { name: "JavaScript", slug: "javascript" },
      { name: "TypeScript", slug: "typescript" },
      { name: "CSS", slug: "css" },
      { name: "Frontend", slug: "frontend" },
      { name: "Backend", slug: "backend" },
      { name: "Best Practices", slug: "best-practices" },
      { name: "Performance", slug: "performance" },
      { name: "Architecture", slug: "architecture" },
    ]

    for (const tag of tags) {
      await prisma.tag.upsert({
        where: { slug: tag.slug },
        update: {},
        create: tag,
      })
    }
    console.log("✅ Tags created")

    console.log("🎉 Database seeded successfully!")
  } catch (error) {
    console.error("❌ Database seeding failed:", error)
    throw error
  }
}

// Run seed if called directly
if (require.main === module) {
  seedDatabase()
    .then(() => {
      console.log("Seeding completed")
      process.exit(0)
    })
    .catch((error) => {
      console.error("Seeding failed:", error)
      process.exit(1)
    })
}
