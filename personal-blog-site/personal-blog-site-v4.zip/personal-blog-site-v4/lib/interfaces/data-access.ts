// 数据访问接口定义
export interface BlogPost {
  id: string
  title: string
  slug: string
  content: string
  excerpt?: string
  featuredImage?: string
  publishDate: Date
  updateDate: Date
  status: "draft" | "published"
  isFeatured: boolean
  authorName: string
  readingTime: number
  categoryIds: string[]
  tagIds: string[]
  createdAt: Date
}

export interface Category {
  id: string
  name: string
  slug: string
  color?: string
  icon?: string
  createdAt: Date
  updatedAt: Date
}

export interface Tag {
  id: string
  name: string
  slug: string
  createdAt: Date
  updatedAt: Date
}

export interface AdminUser {
  id: string
  username: string
  passwordHash: string
  role: string
  createdAt: Date
  updatedAt: Date
}

export interface SiteConfig {
  id: string
  siteTitle: string
  tagline: string
  authorName: string
  authorBio: string
  authorAvatar?: string
  resumeContent?: string
  resumePdfUrl?: string
  socialLinks: Record<string, string>
  navLinks: Array<{ name: string; href: string }>
  aiAgentPersona: string
  aiAgentKnowledgeBase: string
  aiAgentGreeting: string
  aiAgentIconUrl?: string
  aiAgentVisible: boolean
  postsPerPage: number
  featuredPostsCount: number
  createdAt: Date
  updatedAt: Date
}

// 分页结果接口
export interface PaginatedResult<T> {
  items: T[]
  totalPages: number
  currentPage: number
  totalCount: number
}

// 数据仓库接口
export interface IPostRepository {
  findAll(page?: number, limit?: number, status?: string): Promise<PaginatedResult<BlogPost>>
  findBySlug(slug: string): Promise<BlogPost | null>
  findById(id: string): Promise<BlogPost | null>
  findFeatured(limit?: number): Promise<BlogPost[]>
  findRelated(postId: string, limit?: number): Promise<BlogPost[]>
  search(query: string, page?: number, limit?: number): Promise<PaginatedResult<BlogPost>>
  create(post: Omit<BlogPost, "id" | "createdAt" | "updateDate">): Promise<BlogPost>
  update(id: string, post: Partial<BlogPost>): Promise<BlogPost>
  delete(id: string): Promise<void>
  getSlugs(): Promise<string[]>
}

export interface ICategoryRepository {
  findAll(): Promise<Category[]>
  findById(id: string): Promise<Category | null>
  findBySlug(slug: string): Promise<Category | null>
  create(category: Omit<Category, "id" | "createdAt" | "updatedAt">): Promise<Category>
  update(id: string, category: Partial<Category>): Promise<Category>
  delete(id: string): Promise<void>
}

export interface ITagRepository {
  findAll(): Promise<Tag[]>
  findById(id: string): Promise<Tag | null>
  findBySlug(slug: string): Promise<Tag | null>
  create(tag: Omit<Tag, "id" | "createdAt" | "updatedAt">): Promise<Tag>
  update(id: string, tag: Partial<Tag>): Promise<Tag>
  delete(id: string): Promise<void>
}

export interface IAdminUserRepository {
  findByUsername(username: string): Promise<AdminUser | null>
  findById(id: string): Promise<AdminUser | null>
  create(user: Omit<AdminUser, "id" | "createdAt" | "updatedAt">): Promise<AdminUser>
  update(id: string, user: Partial<AdminUser>): Promise<AdminUser>
}

export interface ISiteConfigRepository {
  get(): Promise<SiteConfig>
  update(config: Partial<SiteConfig>): Promise<SiteConfig>
}

// 数据访问层接口
export interface IDataAccess {
  posts: IPostRepository
  categories: ICategoryRepository
  tags: ITagRepository
  adminUsers: IAdminUserRepository
  siteConfig: ISiteConfigRepository
}
