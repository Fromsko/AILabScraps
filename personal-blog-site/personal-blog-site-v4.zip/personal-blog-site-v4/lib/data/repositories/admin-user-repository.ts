import { FileSystemStorage } from "../file-system-storage"
import type { IAdminUserRepository, AdminUser } from "../../interfaces/data-access"

export class AdminUserRepository extends FileSystemStorage<AdminUser> implements IAdminUserRepository {
  constructor() {
    super(process.cwd() + "/data", "admin-users.json")
  }

  async findByUsername(username: string): Promise<AdminUser | null> {
    const users = await this.readData()
    return users.find((user) => user.username === username) || null
  }

  async create(user: Omit<AdminUser, "id" | "createdAt" | "updatedAt">): Promise<AdminUser> {
    const now = new Date()
    const newUser: AdminUser = {
      ...user,
      id: "",
      createdAt: now,
      updatedAt: now,
    }

    return super.create(newUser)
  }

  async update(id: string, updates: Partial<AdminUser>): Promise<AdminUser> {
    const updateData = {
      ...updates,
      updatedAt: new Date(),
    }

    return super.update(id, updateData)
  }
}
