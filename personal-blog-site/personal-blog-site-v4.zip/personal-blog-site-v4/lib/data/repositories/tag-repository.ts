import { FileSystemStorage } from "../file-system-storage"
import type { ITagRepository, Tag } from "../../interfaces/data-access"

export class TagRepository extends FileSystemStorage<Tag> implements ITagRepository {
  constructor() {
    super(process.cwd() + "/data", "tags.json")
  }

  async findBySlug(slug: string): Promise<Tag | null> {
    const tags = await this.readData()
    return tags.find((tag) => tag.slug === slug) || null
  }

  async findAll(): Promise<Tag[]> {
    const tags = await this.readData()
    return tags.sort((a, b) => a.name.localeCompare(b.name))
  }

  async create(tag: Omit<Tag, "id" | "createdAt" | "updatedAt">): Promise<Tag> {
    const now = new Date()
    const newTag: Tag = {
      ...tag,
      id: "",
      createdAt: now,
      updatedAt: now,
    }

    return super.create(newTag)
  }

  async update(id: string, updates: Partial<Tag>): Promise<Tag> {
    const updateData = {
      ...updates,
      updatedAt: new Date(),
    }

    return super.update(id, updateData)
  }
}
