import { FileSystemStorage } from "../file-system-storage"
import type { IPostRepository, BlogPost, PaginatedResult } from "../../interfaces/data-access"

export class PostRepository extends FileSystemStorage<BlogPost> implements IPostRepository {
  constructor() {
    super(process.cwd() + "/data", "posts.json")
  }

  async findAll(page = 1, limit = 10, status?: string): Promise<PaginatedResult<BlogPost>> {
    const allPosts = await this.readData()

    let filteredPosts = allPosts
    if (status) {
      filteredPosts = allPosts.filter((post) => post.status === status)
    }

    // 按发布日期排序
    filteredPosts.sort((a, b) => new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime())

    const totalCount = filteredPosts.length
    const totalPages = Math.ceil(totalCount / limit)
    const startIndex = (page - 1) * limit
    const items = filteredPosts.slice(startIndex, startIndex + limit)

    return {
      items,
      totalPages,
      currentPage: page,
      totalCount,
    }
  }

  async findBySlug(slug: string): Promise<BlogPost | null> {
    const posts = await this.readData()
    return posts.find((post) => post.slug === slug) || null
  }

  async findFeatured(limit = 3): Promise<BlogPost[]> {
    const posts = await this.readData()
    return posts
      .filter((post) => post.status === "published" && post.isFeatured)
      .sort((a, b) => new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime())
      .slice(0, limit)
  }

  async findRelated(postId: string, limit = 3): Promise<BlogPost[]> {
    const posts = await this.readData()
    const currentPost = posts.find((p) => p.id === postId)

    if (!currentPost) return []

    // 找到有相同分类或标签的文章
    const relatedPosts = posts.filter((post) => {
      if (post.id === postId || post.status !== "published") return false

      const hasCommonCategory = post.categoryIds.some((catId) => currentPost.categoryIds.includes(catId))
      const hasCommonTag = post.tagIds.some((tagId) => currentPost.tagIds.includes(tagId))

      return hasCommonCategory || hasCommonTag
    })

    return relatedPosts
      .sort((a, b) => new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime())
      .slice(0, limit)
  }

  async search(query: string, page = 1, limit = 10): Promise<PaginatedResult<BlogPost>> {
    const posts = await this.readData()
    const searchTerm = query.toLowerCase()

    const filteredPosts = posts.filter((post) => {
      if (post.status !== "published") return false

      return (
        post.title.toLowerCase().includes(searchTerm) ||
        post.content.toLowerCase().includes(searchTerm) ||
        (post.excerpt && post.excerpt.toLowerCase().includes(searchTerm))
      )
    })

    filteredPosts.sort((a, b) => new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime())

    const totalCount = filteredPosts.length
    const totalPages = Math.ceil(totalCount / limit)
    const startIndex = (page - 1) * limit
    const items = filteredPosts.slice(startIndex, startIndex + limit)

    return {
      items,
      totalPages,
      currentPage: page,
      totalCount,
    }
  }

  async create(post: Omit<BlogPost, "id" | "createdAt" | "updateDate">): Promise<BlogPost> {
    const now = new Date()
    const newPost: BlogPost = {
      ...post,
      id: "",
      createdAt: now,
      updateDate: now,
    }

    return super.create(newPost)
  }

  async update(id: string, updates: Partial<BlogPost>): Promise<BlogPost> {
    const updateData = {
      ...updates,
      updateDate: new Date(),
    }

    return super.update(id, updateData)
  }

  async getSlugs(): Promise<string[]> {
    const posts = await this.readData()
    return posts.filter((post) => post.status === "published").map((post) => post.slug)
  }
}
