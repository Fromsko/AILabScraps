import { FileSystemStorage } from "../file-system-storage"
import type { ISiteConfigRepository, SiteConfig } from "../../interfaces/data-access"

export class SiteConfigRepository extends FileSystemStorage<SiteConfig> implements ISiteConfigRepository {
  constructor() {
    super(process.cwd() + "/data", "site-config.json")
  }

  async get(): Promise<SiteConfig> {
    const configs = await this.readData()

    if (configs.length === 0) {
      // 创建默认配置
      const defaultConfig: SiteConfig = {
        id: "main",
        siteTitle: "Personal Blog - Insights & Stories",
        tagline: "Sharing insights, stories, and experiences in technology, life, and everything in between.",
        authorName: "Blog Author",
        authorBio:
          "Welcome to my personal blog where I share insights, stories, and experiences in technology, life, and everything in between.",
        socialLinks: {
          github: "https://github.com/yourusername",
          linkedin: "https://linkedin.com/in/yourusername",
          twitter: "https://twitter.com/yourusername",
          email: "your.email@example.com",
        },
        navLinks: [
          { name: "Home", href: "/" },
          { name: "About", href: "/about" },
          { name: "Resume", href: "/resume" },
          { name: "Contact", href: "/contact" },
        ],
        aiAgentPersona:
          "I am a helpful AI assistant for this personal blog. I can answer questions about the blog content, the author, and help you navigate the site.",
        aiAgentKnowledgeBase:
          "About the Author: Full-stack developer with expertise in React, Next.js, TypeScript, and modern web technologies.",
        aiAgentGreeting:
          "Hi! I'm here to help you explore this blog and answer any questions about the content or the author. What would you like to know?",
        aiAgentVisible: true,
        postsPerPage: 6,
        featuredPostsCount: 3,
        createdAt: new Date(),
        updatedAt: new Date(),
      }

      return this.create(defaultConfig)
    }

    return configs[0]
  }

  async update(updates: Partial<SiteConfig>): Promise<SiteConfig> {
    const config = await this.get()
    const updateData = {
      ...updates,
      updatedAt: new Date(),
    }

    return super.update(config.id, updateData)
  }
}
