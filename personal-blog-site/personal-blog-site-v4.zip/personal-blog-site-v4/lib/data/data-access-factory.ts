import type { IDataAccess } from "../interfaces/data-access"
import { PostRepository } from "./repositories/post-repository"
import { CategoryRepository } from "./repositories/category-repository"
import { TagRepository } from "./repositories/tag-repository"
import { AdminUserRepository } from "./repositories/admin-user-repository"
import { SiteConfigRepository } from "./repositories/site-config-repository"

class FileSystemDataAccess implements IDataAccess {
  public readonly posts: PostRepository
  public readonly categories: CategoryRepository
  public readonly tags: TagRepository
  public readonly adminUsers: AdminUserRepository
  public readonly siteConfig: SiteConfigRepository

  constructor() {
    this.posts = new PostRepository()
    this.categories = new CategoryRepository()
    this.tags = new TagRepository()
    this.adminUsers = new AdminUserRepository()
    this.siteConfig = new SiteConfigRepository()
  }
}

// 单例模式
let dataAccessInstance: IDataAccess | null = null

export function getDataAccess(): IDataAccess {
  if (!dataAccessInstance) {
    dataAccessInstance = new FileSystemDataAccess()
  }
  return dataAccessInstance
}

// 预留接口，方便后续切换到其他数据存储
export function setDataAccess(dataAccess: IDataAccess): void {
  dataAccessInstance = dataAccess
}
