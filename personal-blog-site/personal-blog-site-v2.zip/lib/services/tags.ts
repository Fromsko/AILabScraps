import { prisma } from "../prisma"
import type { CreateTag } from "../schemas"

export async function getAllTags() {
  return await prisma.tag.findMany({
    orderBy: { name: "asc" },
    include: {
      _count: {
        select: { posts: true },
      },
    },
  })
}

export async function getTagBySlug(slug: string) {
  return await prisma.tag.findUnique({
    where: { slug },
  })
}

export async function createTag(data: CreateTag) {
  return await prisma.tag.create({
    data,
  })
}

export async function updateTag(id: string, data: Partial<CreateTag>) {
  return await prisma.tag.update({
    where: { id },
    data,
  })
}

export async function deleteTag(id: string) {
  return await prisma.tag.delete({
    where: { id },
  })
}
