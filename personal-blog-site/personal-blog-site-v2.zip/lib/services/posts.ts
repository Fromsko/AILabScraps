import { prisma } from "../prisma"
import type { CreatePost, UpdatePost } from "../schemas"

export async function getAllPosts(options?: {
  status?: "draft" | "published"
  featured?: boolean
  categoryId?: string
  tagId?: string
  search?: string
  page?: number
  limit?: number
}) {
  const { status, featured, categoryId, tagId, search, page = 1, limit = 10 } = options || {}

  const where: any = {}

  if (status) {
    where.status = status
  }

  if (featured !== undefined) {
    where.isFeatured = featured
  }

  if (categoryId) {
    where.categories = {
      some: { categoryId },
    }
  }

  if (tagId) {
    where.tags = {
      some: { tagId },
    }
  }

  if (search) {
    where.OR = [
      { title: { contains: search, mode: "insensitive" } },
      { content: { contains: search, mode: "insensitive" } },
      { excerpt: { contains: search, mode: "insensitive" } },
    ]
  }

  const [posts, total] = await Promise.all([
    prisma.post.findMany({
      where,
      include: {
        author: {
          select: { id: true, username: true, email: true },
        },
        categories: {
          include: { category: true },
        },
        tags: {
          include: { tag: true },
        },
      },
      orderBy: { publishDate: "desc" },
      skip: (page - 1) * limit,
      take: limit,
    }),
    prisma.post.count({ where }),
  ])

  return {
    posts: posts.map((post) => ({
      ...post,
      categories: post.categories.map((pc) => pc.category),
      tags: post.tags.map((pt) => pt.tag),
    })),
    total,
    pages: Math.ceil(total / limit),
    currentPage: page,
  }
}

export async function getPostBySlug(slug: string) {
  const post = await prisma.post.findUnique({
    where: { slug },
    include: {
      author: {
        select: { id: true, username: true, email: true },
      },
      categories: {
        include: { category: true },
      },
      tags: {
        include: { tag: true },
      },
    },
  })

  if (!post) return null

  return {
    ...post,
    categories: post.categories.map((pc) => pc.category),
    tags: post.tags.map((pt) => pt.tag),
  }
}

export async function createPost(data: CreatePost, authorId: string) {
  const { categoryIds, tagIds, ...postData } = data

  return await prisma.post.create({
    data: {
      ...postData,
      authorId,
      readingTime: calculateReadingTime(data.content),
      categories: {
        create: categoryIds.map((categoryId) => ({ categoryId })),
      },
      tags: {
        create: tagIds.map((tagId) => ({ tagId })),
      },
    },
    include: {
      categories: {
        include: { category: true },
      },
      tags: {
        include: { tag: true },
      },
    },
  })
}

export async function updatePost(id: string, data: UpdatePost) {
  const { categoryIds, tagIds, ...postData } = data

  // Update reading time if content changed
  if (data.content) {
    postData.readingTime = calculateReadingTime(data.content)
  }

  return await prisma.$transaction(async (tx) => {
    // Update the post
    const updatedPost = await tx.post.update({
      where: { id },
      data: postData,
    })

    // Update categories if provided
    if (categoryIds) {
      await tx.postCategory.deleteMany({
        where: { postId: id },
      })
      await tx.postCategory.createMany({
        data: categoryIds.map((categoryId) => ({ postId: id, categoryId })),
      })
    }

    // Update tags if provided
    if (tagIds) {
      await tx.postTag.deleteMany({
        where: { postId: id },
      })
      await tx.postTag.createMany({
        data: tagIds.map((tagId) => ({ postId: id, tagId })),
      })
    }

    return updatedPost
  })
}

export async function deletePost(id: string) {
  return await prisma.post.delete({
    where: { id },
  })
}

function calculateReadingTime(content: string): number {
  const wordsPerMinute = 200
  const wordCount = content.split(/\s+/).length
  return Math.ceil(wordCount / wordsPerMinute)
}
