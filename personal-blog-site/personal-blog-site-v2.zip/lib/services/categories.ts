import { prisma } from "../prisma"
import type { CreateCategory } from "../schemas"

export async function getAllCategories() {
  return await prisma.category.findMany({
    orderBy: { name: "asc" },
    include: {
      _count: {
        select: { posts: true },
      },
    },
  })
}

export async function getCategoryBySlug(slug: string) {
  return await prisma.category.findUnique({
    where: { slug },
  })
}

export async function createCategory(data: CreateCategory) {
  return await prisma.category.create({
    data,
  })
}

export async function updateCategory(id: string, data: Partial<CreateCategory>) {
  return await prisma.category.update({
    where: { id },
    data,
  })
}

export async function deleteCategory(id: string) {
  return await prisma.category.delete({
    where: { id },
  })
}
