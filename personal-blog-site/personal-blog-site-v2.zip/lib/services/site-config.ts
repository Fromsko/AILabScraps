import { prisma } from "../prisma"
import type { SiteConfig } from "../schemas"

export async function getSiteConfig(): Promise<SiteConfig> {
  const config = await prisma.siteConfig.findUnique({
    where: { id: "main" },
  })

  if (!config) {
    throw new Error("Site configuration not found")
  }

  return {
    siteTitle: config.siteTitle,
    tagline: config.tagline,
    authorName: config.authorName,
    authorBio: config.authorBio,
    authorAvatar: config.authorAvatar || undefined,
    resumeContent: config.resumeContent || undefined,
    resumePdfUrl: config.resumePdfUrl || undefined,
    socialLinks: JSON.parse(config.socialLinks),
    navLinks: JSON.parse(config.navLinks),
    aiAgentPersona: config.aiAgentPersona,
    aiAgentKnowledge: config.aiAgentKnowledge,
    aiAgentGreeting: config.aiAgentGreeting,
    aiAgentIconUrl: config.aiAgentIconUrl || undefined,
    aiAgentVisible: config.aiAgentVisible,
    postsPerPage: config.postsPerPage,
    featuredPostsCount: config.featuredPostsCount,
  }
}

export async function updateSiteConfig(data: Partial<SiteConfig>) {
  const updateData: any = { ...data }

  if (data.socialLinks) {
    updateData.socialLinks = JSON.stringify(data.socialLinks)
  }

  if (data.navLinks) {
    updateData.navLinks = JSON.stringify(data.navLinks)
  }

  return await prisma.siteConfig.update({
    where: { id: "main" },
    data: updateData,
  })
}
