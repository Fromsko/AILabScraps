import { z } from "zod"

// Post schemas
export const PostSchema = z.object({
  id: z.string(),
  title: z.string(),
  slug: z.string(),
  content: z.string(),
  excerpt: z.string().optional(),
  featuredImage: z.string().optional(),
  publishDate: z.date(),
  updatedAt: z.date(),
  status: z.enum(["draft", "published"]),
  isFeatured: z.boolean(),
  readingTime: z.number(),
  authorId: z.string(),
  categories: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      slug: z.string(),
      color: z.string(),
      icon: z.string().optional(),
    }),
  ),
  tags: z.array(
    z.object({
      id: z.string(),
      name: z.string(),
      slug: z.string(),
    }),
  ),
})

export const CreatePostSchema = z.object({
  title: z.string().min(1, "Title is required"),
  slug: z.string().min(1, "Slug is required"),
  content: z.string().min(1, "Content is required"),
  excerpt: z.string().optional(),
  featuredImage: z.string().url().optional().or(z.literal("")),
  status: z.enum(["draft", "published"]),
  isFeatured: z.boolean().default(false),
  categoryIds: z.array(z.string()),
  tagIds: z.array(z.string()),
})

export const UpdatePostSchema = CreatePostSchema.partial().extend({
  id: z.string(),
})

// Category schemas
export const CategorySchema = z.object({
  id: z.string(),
  name: z.string(),
  slug: z.string(),
  color: z.string(),
  icon: z.string().optional(),
})

export const CreateCategorySchema = z.object({
  name: z.string().min(1, "Name is required"),
  slug: z.string().min(1, "Slug is required"),
  color: z.string().default("#3B82F6"),
  icon: z.string().optional(),
})

// Tag schemas
export const TagSchema = z.object({
  id: z.string(),
  name: z.string(),
  slug: z.string(),
})

export const CreateTagSchema = z.object({
  name: z.string().min(1, "Name is required"),
  slug: z.string().min(1, "Slug is required"),
})

// Site config schemas
export const SiteConfigSchema = z.object({
  siteTitle: z.string(),
  tagline: z.string(),
  authorName: z.string(),
  authorBio: z.string(),
  authorAvatar: z.string().optional(),
  resumeContent: z.string().optional(),
  resumePdfUrl: z.string().url().optional().or(z.literal("")),
  socialLinks: z.record(z.string()),
  navLinks: z.array(
    z.object({
      name: z.string(),
      href: z.string(),
    }),
  ),
  aiAgentPersona: z.string(),
  aiAgentKnowledge: z.string(),
  aiAgentGreeting: z.string(),
  aiAgentIconUrl: z.string().optional(),
  aiAgentVisible: z.boolean(),
  postsPerPage: z.number().min(1).max(20),
  featuredPostsCount: z.number().min(1).max(10),
})

// AI Chat schemas
export const ChatMessageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string(),
})

export const ChatRequestSchema = z.object({
  messages: z.array(ChatMessageSchema),
  currentPage: z.string().optional(),
})

// Auth schemas
export const LoginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
})

export type Post = z.infer<typeof PostSchema>
export type CreatePost = z.infer<typeof CreatePostSchema>
export type UpdatePost = z.infer<typeof UpdatePostSchema>
export type Category = z.infer<typeof CategorySchema>
export type CreateCategory = z.infer<typeof CreateCategorySchema>
export type Tag = z.infer<typeof TagSchema>
export type CreateTag = z.infer<typeof CreateTagSchema>
export type SiteConfig = z.infer<typeof SiteConfigSchema>
export type ChatMessage = z.infer<typeof ChatMessageSchema>
export type ChatRequest = z.infer<typeof ChatRequestSchema>
export type LoginData = z.infer<typeof LoginSchema>
