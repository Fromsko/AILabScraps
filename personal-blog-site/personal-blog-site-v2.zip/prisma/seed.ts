import { PrismaClient } from "@prisma/client"
import bcrypt from "bcryptjs"

const prisma = new PrismaClient()

async function main() {
  // Create admin user
  const hashedPassword = await bcrypt.hash("admin123", 12)

  const adminUser = await prisma.user.upsert({
    where: { email: "admin@example.com" },
    update: {},
    create: {
      email: "admin@example.com",
      username: "admin",
      password: hashedPassword,
      role: "admin",
    },
  })

  // Create site config
  const siteConfig = await prisma.siteConfig.upsert({
    where: { id: "main" },
    update: {},
    create: {
      id: "main",
      siteTitle: "AI-Powered Blog & Portfolio",
      tagline: "Sharing insights, stories, and AI-powered experiences",
      authorName: "John Doe",
      authorBio:
        "Full-stack developer, AI enthusiast, and passionate writer sharing insights about technology, development, and life.",
      socialLinks: JSON.stringify({
        twitter: "https://twitter.com/johndoe",
        linkedin: "https://linkedin.com/in/johndoe",
        github: "https://github.com/johndoe",
        email: "john@example.com",
      }),
      navLinks: JSON.stringify([
        { name: "Home", href: "/" },
        { name: "Blog", href: "/blog" },
        { name: "About", href: "/about" },
        { name: "Resume", href: "/resume" },
        { name: "Contact", href: "/contact" },
      ]),
      aiAgentPersona:
        "I am John's AI assistant. I can help you learn about his work, blog posts, and answer questions about web development, AI, and technology. I have access to all his published content and can provide insights based on his expertise.",
      aiAgentKnowledge: `
        John Doe is a full-stack developer with 8+ years of experience.
        Specializes in: React, Next.js, TypeScript, Node.js, Python, AI/ML
        Current focus: Building AI-powered web applications
        Education: Computer Science degree from MIT
        Location: San Francisco, CA
        Interests: AI/ML, web development, open source, hiking, photography
        Recent projects: AI-powered blog platform, e-commerce solutions, developer tools
      `,
      resumeContent: `
        <h2>Experience</h2>
        <div class="mb-6">
          <h3 class="text-lg font-semibold">Senior Full-Stack Developer</h3>
          <p class="text-gray-600">TechCorp Inc. • 2020 - Present</p>
          <ul class="list-disc list-inside mt-2">
            <li>Led development of AI-powered web applications</li>
            <li>Mentored junior developers and established best practices</li>
            <li>Improved application performance by 40%</li>
          </ul>
        </div>
        
        <h2>Skills</h2>
        <div class="grid grid-cols-2 gap-4 mb-6">
          <div>
            <h4 class="font-medium">Frontend</h4>
            <p>React, Next.js, TypeScript, Tailwind CSS</p>
          </div>
          <div>
            <h4 class="font-medium">Backend</h4>
            <p>Node.js, Python, PostgreSQL, MongoDB</p>
          </div>
        </div>
      `,
    },
  })

  // Create sample categories
  const webDevCategory = await prisma.category.upsert({
    where: { slug: "web-development" },
    update: {},
    create: {
      name: "Web Development",
      slug: "web-development",
      color: "#3B82F6",
      icon: "💻",
    },
  })

  const aiCategory = await prisma.category.upsert({
    where: { slug: "artificial-intelligence" },
    update: {},
    create: {
      name: "Artificial Intelligence",
      slug: "artificial-intelligence",
      color: "#8B5CF6",
      icon: "🤖",
    },
  })

  // Create sample tags
  const reactTag = await prisma.tag.upsert({
    where: { slug: "react" },
    update: {},
    create: {
      name: "React",
      slug: "react",
    },
  })

  const nextjsTag = await prisma.tag.upsert({
    where: { slug: "nextjs" },
    update: {},
    create: {
      name: "Next.js",
      slug: "nextjs",
    },
  })

  const aiTag = await prisma.tag.upsert({
    where: { slug: "ai" },
    update: {},
    create: {
      name: "AI",
      slug: "ai",
    },
  })

  // Create sample blog posts
  const post1 = await prisma.post.upsert({
    where: { slug: "building-ai-powered-web-apps" },
    update: {},
    create: {
      title: "Building AI-Powered Web Applications with Next.js",
      slug: "building-ai-powered-web-apps",
      content: `
# Building AI-Powered Web Applications with Next.js

The integration of AI into web applications has become increasingly important in modern development. In this comprehensive guide, we'll explore how to build sophisticated AI-powered web applications using Next.js and the latest AI technologies.

## Table of Contents

## Why AI-Powered Web Apps?

AI integration offers numerous benefits:
- Enhanced user experience through personalization
- Automated content generation and curation
- Intelligent data analysis and insights
- Natural language interfaces

## Getting Started with the Vercel AI SDK

The Vercel AI SDK provides a seamless way to integrate AI capabilities into your Next.js applications...

## Implementation Examples

Let's look at some practical examples of AI integration...

## Best Practices

When building AI-powered applications, consider these best practices...

## Conclusion

AI integration in web applications opens up exciting possibilities for creating more intelligent and responsive user experiences.
      `,
      excerpt:
        "Learn how to integrate AI capabilities into your Next.js applications using the Vercel AI SDK and modern development practices.",
      featuredImage: "/placeholder.svg?height=400&width=600",
      status: "published",
      isFeatured: true,
      readingTime: 8,
      authorId: adminUser.id,
      categories: {
        create: [{ categoryId: webDevCategory.id }, { categoryId: aiCategory.id }],
      },
      tags: {
        create: [{ tagId: nextjsTag.id }, { tagId: aiTag.id }],
      },
    },
  })

  console.log("Database seeded successfully!")
  console.log("Admin user created:", { email: "admin@example.com", password: "admin123" })
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
