import type { NextRequest } from "next/server"
import { openai } from "@ai-sdk/openai"
import { streamText, tool } from "ai"
import { z } from "zod"
import { getSiteConfig } from "@/lib/services/site-config"
import { getAllPosts } from "@/lib/services/posts"
import { getAllCategories } from "@/lib/services/categories"

export async function POST(req: NextRequest) {
  try {
    const { messages, currentPage } = await req.json()

    // Get site configuration and AI agent settings
    const siteConfig = await getSiteConfig()

    // Define tools for the AI agent
    const tools = {
      getLatestPosts: tool({
        description: "Get the latest published blog posts",
        parameters: z.object({
          limit: z.number().optional().default(5),
        }),
        execute: async ({ limit }) => {
          const result = await getAllPosts({
            status: "published",
            limit,
          })
          return result.posts.map((post) => ({
            title: post.title,
            slug: post.slug,
            excerpt: post.excerpt,
            publishDate: post.publishDate,
            categories: post.categories.map((c) => c.name),
            tags: post.tags.map((t) => t.name),
          }))
        },
      }),

      searchPosts: tool({
        description: "Search for blog posts by title or content",
        parameters: z.object({
          query: z.string().describe("Search query"),
        }),
        execute: async ({ query }) => {
          const result = await getAllPosts({
            status: "published",
            search: query,
            limit: 5,
          })
          return result.posts.map((post) => ({
            title: post.title,
            slug: post.slug,
            excerpt: post.excerpt,
            publishDate: post.publishDate,
          }))
        },
      }),

      getCategories: tool({
        description: "Get all blog post categories",
        parameters: z.object({}),
        execute: async () => {
          const categories = await getAllCategories()
          return categories.map((cat) => ({
            name: cat.name,
            slug: cat.slug,
            postCount: cat._count.posts,
          }))
        },
      }),

      getAuthorInfo: tool({
        description: "Get information about the blog author",
        parameters: z.object({}),
        execute: async () => {
          return {
            name: siteConfig.authorName,
            bio: siteConfig.authorBio,
            socialLinks: siteConfig.socialLinks,
          }
        },
      }),
    }

    // Construct the system prompt using PromptX principles
    const systemPrompt = `
You are ${siteConfig.authorName}'s AI assistant. ${siteConfig.aiAgentPersona}

CONTEXT ABOUT THE AUTHOR:
${siteConfig.aiAgentKnowledge}

CURRENT PAGE CONTEXT:
${currentPage ? `The user is currently viewing: ${currentPage}` : "The user is browsing the website"}

CAPABILITIES:
- Answer questions about ${siteConfig.authorName}'s work, experience, and blog content
- Search and retrieve specific blog posts
- Provide information about blog categories and topics
- Share author contact information and social links
- Help users navigate the website

PERSONALITY:
- Helpful and knowledgeable
- Professional but friendly
- Concise but thorough when needed
- Always accurate about the author's information

GUIDELINES:
- Use the available tools to fetch real-time data when needed
- If you don't know something specific, say so rather than guessing
- Encourage users to read the full blog posts for detailed information
- Be conversational and engaging
    `

    const result = await streamText({
      model: openai("gpt-4o"),
      system: systemPrompt,
      messages,
      tools,
      maxToolRoundtrips: 3,
    })

    return result.toAIStreamResponse()
  } catch (error) {
    console.error("Chat API error:", error)
    return new Response("Internal Server Error", { status: 500 })
  }
}
