import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { getSiteConfig, updateSiteConfig } from "@/lib/services/site-config"
import { SiteConfigSchema } from "@/lib/schemas"

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const config = await getSiteConfig()
    return NextResponse.json(config)
  } catch (error) {
    console.error("Error fetching site config:", error)
    return NextResponse.json({ error: "Failed to fetch site config" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const validatedData = SiteConfigSchema.partial().parse(body)

    const config = await updateSiteConfig(validatedData)

    return NextResponse.json(config)
  } catch (error) {
    console.error("Error updating site config:", error)
    return NextResponse.json({ error: "Failed to update site config" }, { status: 500 })
  }
}
