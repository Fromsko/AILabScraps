"use client"

import { useState, useEffect } from "react"
import { useChat } from "ai/react"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageCircle, X, Send, Bot, User } from "lucide-react"
import { cn } from "@/lib/utils"

interface FloatingAIWidgetProps {
  config: {
    aiAgentVisible: boolean
    aiAgentGreeting: string
    aiAgentIconUrl?: string
  }
}

export function FloatingAIWidget({ config }: FloatingAIWidgetProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [hasGreeted, setHasGreeted] = useState(false)
  const pathname = usePathname()

  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: "/api/chat",
    body: {
      currentPage: pathname,
    },
    initialMessages: [],
  })

  // Add greeting message when chat opens for the first time
  useEffect(() => {
    if (isOpen && !hasGreeted && messages.length === 0) {
      setHasGreeted(true)
      // We'll add the greeting message manually to the UI since we can't modify the useChat messages directly
    }
  }, [isOpen, hasGreeted, messages.length])

  if (!config.aiAgentVisible) {
    return null
  }

  return (
    <>
      {/* Floating Button */}
      {!isOpen && (
        <Button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg z-50"
          size="icon"
        >
          {config.aiAgentIconUrl ? (
            <img
              src={config.aiAgentIconUrl || "/placeholder.svg"}
              alt="AI Assistant"
              className="h-8 w-8 rounded-full"
            />
          ) : (
            <MessageCircle className="h-6 w-6" />
          )}
        </Button>
      )}

      {/* Chat Interface */}
      {isOpen && (
        <Card className="fixed bottom-6 right-6 w-96 h-[500px] shadow-xl z-50 flex flex-col">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
            <CardTitle className="text-lg flex items-center">
              <Bot className="h-5 w-5 mr-2" />
              AI Assistant
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="h-8 w-8">
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>

          <CardContent className="flex-1 flex flex-col p-4 pt-0">
            <ScrollArea className="flex-1 pr-4">
              <div className="space-y-4">
                {/* Greeting Message */}
                {!hasGreeted && (
                  <div className="flex items-start space-x-2">
                    <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-full">
                      <Bot className="h-4 w-4 text-blue-600 dark:text-blue-300" />
                    </div>
                    <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 max-w-[280px]">
                      <p className="text-sm">{config.aiAgentGreeting}</p>
                    </div>
                  </div>
                )}

                {/* Chat Messages */}
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={cn(
                      "flex items-start space-x-2",
                      message.role === "user" ? "justify-end" : "justify-start",
                    )}
                  >
                    {message.role === "assistant" && (
                      <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-full">
                        <Bot className="h-4 w-4 text-blue-600 dark:text-blue-300" />
                      </div>
                    )}

                    <div
                      className={cn(
                        "rounded-lg p-3 max-w-[280px]",
                        message.role === "user" ? "bg-blue-600 text-white" : "bg-gray-100 dark:bg-gray-800",
                      )}
                    >
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    </div>

                    {message.role === "user" && (
                      <div className="bg-blue-600 p-2 rounded-full">
                        <User className="h-4 w-4 text-white" />
                      </div>
                    )}
                  </div>
                ))}

                {/* Loading indicator */}
                {isLoading && (
                  <div className="flex items-start space-x-2">
                    <div className="bg-blue-100 dark:bg-blue-900 p-2 rounded-full">
                      <Bot className="h-4 w-4 text-blue-600 dark:text-blue-300" />
                    </div>
                    <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-3">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.1s" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>

            {/* Input Form */}
            <form onSubmit={handleSubmit} className="flex space-x-2 mt-4">
              <Input
                value={input}
                onChange={handleInputChange}
                placeholder="Ask me anything..."
                disabled={isLoading}
                className="flex-1"
              />
              <Button type="submit" size="icon" disabled={isLoading || !input.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </CardContent>
        </Card>
      )}
    </>
  )
}
