"use client"

import { signOut, useSession } from "next-auth/react"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import { LogOut, User } from "lucide-react"

export function AdminHeader() {
  const { data: session } = useSession()

  return (
    <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
      <div className="px-6 py-4 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-gray-900 dark:text-white">Admin Dashboard</h1>
        </div>

        <div className="flex items-center space-x-4">
          <ThemeToggle />

          <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-300">
            <User className="h-4 w-4" />
            <span>{session?.user?.name}</span>
          </div>

          <Button variant="outline" size="sm" onClick={() => signOut({ callbackUrl: "/admin/login" })}>
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </Button>
        </div>
      </div>
    </header>
  )
}
