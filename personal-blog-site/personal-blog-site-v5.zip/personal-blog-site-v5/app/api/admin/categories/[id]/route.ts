import { type NextRequest, NextResponse } from "next/server"
import { getDataAccess } from "@/lib/data/data-access-factory"
import { CategorySchema } from "@/lib/schemas"
import { verifyToken } from "@/lib/auth"

async function verifyAuth(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) throw new Error("Not authenticated")

  const decoded = verifyToken(token)
  if (!decoded) throw new Error("Invalid token")

  return decoded.userId
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await verifyAuth(request)

    const dataAccess = getDataAccess()
    const category = await dataAccess.categories.findById(params.id)

    if (!category) {
      return NextResponse.json({ error: "Category not found" }, { status: 404 })
    }

    return NextResponse.json(category)
  } catch (error) {
    console.error("Get category error:", error)
    return NextResponse.json({ error: "Failed to fetch category" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await verifyAuth(request)

    const body = await request.json()
    const validatedData = CategorySchema.parse(body)

    const dataAccess = getDataAccess()
    const category = await dataAccess.categories.update(params.id, validatedData)

    return NextResponse.json(category)
  } catch (error) {
    console.error("Update category error:", error)
    return NextResponse.json({ error: "Failed to update category" }, { status: 400 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await verifyAuth(request)

    const dataAccess = getDataAccess()
    await dataAccess.categories.delete(params.id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Delete category error:", error)
    return NextResponse.json({ error: "Failed to delete category" }, { status: 500 })
  }
}
