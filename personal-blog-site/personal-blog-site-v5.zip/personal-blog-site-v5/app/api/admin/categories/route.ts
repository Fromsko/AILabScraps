import { type NextRequest, NextResponse } from "next/server"
import { getDataAccess } from "@/lib/data/data-access-factory"
import { CategorySchema } from "@/lib/schemas"
import { verifyToken } from "@/lib/auth"

async function verifyAuth(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) throw new Error("Not authenticated")

  const decoded = verifyToken(token)
  if (!decoded) throw new Error("Invalid token")

  return decoded.userId
}

export async function GET(request: NextRequest) {
  try {
    await verifyAuth(request)

    const dataAccess = getDataAccess()
    const categories = await dataAccess.categories.findAll()

    return NextResponse.json({ categories })
  } catch (error) {
    console.error("Get categories error:", error)
    return NextResponse.json({ error: "Failed to fetch categories" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    await verifyAuth(request)

    const body = await request.json()
    const validatedData = CategorySchema.parse(body)

    const dataAccess = getDataAccess()
    const category = await dataAccess.categories.create(validatedData)

    return NextResponse.json(category, { status: 201 })
  } catch (error) {
    console.error("Create category error:", error)
    return NextResponse.json({ error: "Failed to create category" }, { status: 400 })
  }
}
