import { type NextRequest, NextResponse } from "next/server"
import { getDataAccess } from "@/lib/data/data-access-factory"
import { TagSchema } from "@/lib/schemas"
import { verifyToken } from "@/lib/auth"

async function verifyAuth(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) throw new Error("Not authenticated")

  const decoded = verifyToken(token)
  if (!decoded) throw new Error("Invalid token")

  return decoded.userId
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await verifyAuth(request)

    const dataAccess = getDataAccess()
    const tag = await dataAccess.tags.findById(params.id)

    if (!tag) {
      return NextResponse.json({ error: "Tag not found" }, { status: 404 })
    }

    return NextResponse.json(tag)
  } catch (error) {
    console.error("Get tag error:", error)
    return NextResponse.json({ error: "Failed to fetch tag" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await verifyAuth(request)

    const body = await request.json()
    const validatedData = TagSchema.parse(body)

    const dataAccess = getDataAccess()
    const tag = await dataAccess.tags.update(params.id, validatedData)

    return NextResponse.json(tag)
  } catch (error) {
    console.error("Update tag error:", error)
    return NextResponse.json({ error: "Failed to update tag" }, { status: 400 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await verifyAuth(request)

    const dataAccess = getDataAccess()
    await dataAccess.tags.delete(params.id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Delete tag error:", error)
    return NextResponse.json({ error: "Failed to delete tag" }, { status: 500 })
  }
}
