import { type NextRequest, NextResponse } from "next/server"
import { getDataAccess } from "@/lib/data/data-access-factory"
import { TagSchema } from "@/lib/schemas"
import { verifyToken } from "@/lib/auth"

async function verifyAuth(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) throw new Error("Not authenticated")

  const decoded = verifyToken(token)
  if (!decoded) throw new Error("Invalid token")

  return decoded.userId
}

export async function GET(request: NextRequest) {
  try {
    await verifyAuth(request)

    const dataAccess = getDataAccess()
    const tags = await dataAccess.tags.findAll()

    return NextResponse.json({ tags })
  } catch (error) {
    console.error("Get tags error:", error)
    return NextResponse.json({ error: "Failed to fetch tags" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    await verifyAuth(request)

    const body = await request.json()
    const validatedData = TagSchema.parse(body)

    const dataAccess = getDataAccess()
    const tag = await dataAccess.tags.create(validatedData)

    return NextResponse.json(tag, { status: 201 })
  } catch (error) {
    console.error("Create tag error:", error)
    return NextResponse.json({ error: "Failed to create tag" }, { status: 400 })
  }
}
