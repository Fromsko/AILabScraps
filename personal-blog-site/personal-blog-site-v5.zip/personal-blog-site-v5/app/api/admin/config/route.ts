import { type NextRequest, NextResponse } from "next/server"
import { getDataAccess } from "@/lib/data/data-access-factory"
import { SiteConfigSchema } from "@/lib/schemas"
import { verifyToken } from "@/lib/auth"

async function verifyAuth(request: NextRequest) {
  const token = request.cookies.get("admin-token")?.value
  if (!token) throw new Error("Not authenticated")

  const decoded = verifyToken(token)
  if (!decoded) throw new Error("Invalid token")

  return decoded.userId
}

export async function GET(request: NextRequest) {
  try {
    await verifyAuth(request)

    const dataAccess = getDataAccess()
    const config = await dataAccess.siteConfig.get()

    return NextResponse.json(config)
  } catch (error) {
    console.error("Get config error:", error)
    return NextResponse.json({ error: "Failed to fetch configuration" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    await verifyAuth(request)

    const body = await request.json()
    const validatedData = SiteConfigSchema.parse(body)

    const dataAccess = getDataAccess()
    const config = await dataAccess.siteConfig.update(validatedData)

    return NextResponse.json(config)
  } catch (error) {
    console.error("Update config error:", error)
    return NextResponse.json({ error: "Failed to update configuration" }, { status: 400 })
  }
}
