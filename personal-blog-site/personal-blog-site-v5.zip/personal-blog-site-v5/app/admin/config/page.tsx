"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { AdminLayout } from "@/components/admin/admin-layout"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Save, Plus, Trash2 } from "lucide-react"

interface SiteConfig {
  siteTitle: string
  tagline: string
  authorName: string
  authorBio: string
  authorAvatar?: string
  resumeContent?: string
  resumePdfUrl?: string
  socialLinks: Record<string, string>
  navLinks: Array<{ name: string; href: string }>
  aiAgentPersona: string
  aiAgentKnowledgeBase: string
  aiAgentGreeting: string
  aiAgentIconUrl?: string
  aiAgentVisible: boolean
  postsPerPage: number
  featuredPostsCount: number
}

export default function AdminConfigPage() {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [config, setConfig] = useState<SiteConfig | null>(null)

  useEffect(() => {
    loadConfig()
  }, [])

  const loadConfig = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/admin/config")
      if (response.ok) {
        const data = await response.json()
        setConfig(data)
      }
    } catch (error) {
      console.error("Failed to load config:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!config) return

    setSaving(true)

    try {
      const response = await fetch("/api/admin/config", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(config),
      })

      if (response.ok) {
        alert("Configuration saved successfully!")
      } else {
        const error = await response.json()
        alert(error.error || "Failed to save configuration")
      }
    } catch (error) {
      console.error("Failed to save config:", error)
      alert("Failed to save configuration")
    } finally {
      setSaving(false)
    }
  }

  const addSocialLink = () => {
    if (!config) return
    setConfig((prev) => ({
      ...prev!,
      socialLinks: {
        ...prev!.socialLinks,
        "": "",
      },
    }))
  }

  const updateSocialLink = (oldKey: string, newKey: string, value: string) => {
    if (!config) return
    const newSocialLinks = { ...config.socialLinks }
    delete newSocialLinks[oldKey]
    newSocialLinks[newKey] = value
    setConfig((prev) => ({
      ...prev!,
      socialLinks: newSocialLinks,
    }))
  }

  const removeSocialLink = (key: string) => {
    if (!config) return
    const newSocialLinks = { ...config.socialLinks }
    delete newSocialLinks[key]
    setConfig((prev) => ({
      ...prev!,
      socialLinks: newSocialLinks,
    }))
  }

  const addNavLink = () => {
    if (!config) return
    setConfig((prev) => ({
      ...prev!,
      navLinks: [...prev!.navLinks, { name: "", href: "" }],
    }))
  }

  const updateNavLink = (index: number, field: "name" | "href", value: string) => {
    if (!config) return
    const newNavLinks = [...config.navLinks]
    newNavLinks[index] = { ...newNavLinks[index], [field]: value }
    setConfig((prev) => ({
      ...prev!,
      navLinks: newNavLinks,
    }))
  }

  const removeNavLink = (index: number) => {
    if (!config) return
    setConfig((prev) => ({
      ...prev!,
      navLinks: prev!.navLinks.filter((_, i) => i !== index),
    }))
  }

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center py-12">
          <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
        </div>
      </AdminLayout>
    )
  }

  if (!config) {
    return (
      <AdminLayout>
        <div className="text-center py-12">
          <p className="text-gray-500">Failed to load configuration</p>
        </div>
      </AdminLayout>
    )
  }

  return (
    <AdminLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Site Configuration</h1>
            <p className="text-gray-600">Manage your site settings and preferences</p>
          </div>
          <Button onClick={handleSubmit} disabled={saving}>
            {saving ? (
              <>
                <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
                Saving...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </>
            )}
          </Button>
        </div>

        <form onSubmit={handleSubmit}>
          <Tabs defaultValue="general" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="general">General</TabsTrigger>
              <TabsTrigger value="author">Author</TabsTrigger>
              <TabsTrigger value="navigation">Navigation</TabsTrigger>
              <TabsTrigger value="ai">AI Agent</TabsTrigger>
            </TabsList>

            <TabsContent value="general" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Site Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="siteTitle">Site Title *</Label>
                    <Input
                      id="siteTitle"
                      value={config.siteTitle}
                      onChange={(e) => setConfig((prev) => ({ ...prev!, siteTitle: e.target.value }))}
                      placeholder="My Personal Blog"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="tagline">Tagline *</Label>
                    <Input
                      id="tagline"
                      value={config.tagline}
                      onChange={(e) => setConfig((prev) => ({ ...prev!, tagline: e.target.value }))}
                      placeholder="Insights & Stories"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="postsPerPage">Posts Per Page</Label>
                      <Input
                        id="postsPerPage"
                        type="number"
                        min="1"
                        max="20"
                        value={config.postsPerPage}
                        onChange={(e) =>
                          setConfig((prev) => ({ ...prev!, postsPerPage: Number.parseInt(e.target.value) }))
                        }
                      />
                    </div>
                    <div>
                      <Label htmlFor="featuredPostsCount">Featured Posts Count</Label>
                      <Input
                        id="featuredPostsCount"
                        type="number"
                        min="1"
                        max="10"
                        value={config.featuredPostsCount}
                        onChange={(e) =>
                          setConfig((prev) => ({ ...prev!, featuredPostsCount: Number.parseInt(e.target.value) }))
                        }
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="author" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Author Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="authorName">Author Name *</Label>
                    <Input
                      id="authorName"
                      value={config.authorName}
                      onChange={(e) => setConfig((prev) => ({ ...prev!, authorName: e.target.value }))}
                      placeholder="Your Name"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="authorBio">Author Bio *</Label>
                    <Textarea
                      id="authorBio"
                      value={config.authorBio}
                      onChange={(e) => setConfig((prev) => ({ ...prev!, authorBio: e.target.value }))}
                      placeholder="Tell us about yourself..."
                      rows={4}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="authorAvatar">Author Avatar URL</Label>
                    <Input
                      id="authorAvatar"
                      value={config.authorAvatar || ""}
                      onChange={(e) => setConfig((prev) => ({ ...prev!, authorAvatar: e.target.value }))}
                      placeholder="https://example.com/avatar.jpg"
                    />
                  </div>

                  <div>
                    <Label htmlFor="resumeContent">Resume Content</Label>
                    <Textarea
                      id="resumeContent"
                      value={config.resumeContent || ""}
                      onChange={(e) => setConfig((prev) => ({ ...prev!, resumeContent: e.target.value }))}
                      placeholder="Your resume content in markdown..."
                      rows={10}
                    />
                  </div>

                  <div>
                    <Label htmlFor="resumePdfUrl">Resume PDF URL</Label>
                    <Input
                      id="resumePdfUrl"
                      value={config.resumePdfUrl || ""}
                      onChange={(e) => setConfig((prev) => ({ ...prev!, resumePdfUrl: e.target.value }))}
                      placeholder="https://example.com/resume.pdf"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Social Links</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {Object.entries(config.socialLinks).map(([key, value]) => (
                    <div key={key} className="flex items-center space-x-2">
                      <Input
                        placeholder="Platform (e.g., github)"
                        value={key}
                        onChange={(e) => updateSocialLink(key, e.target.value, value)}
                        className="flex-1"
                      />
                      <Input
                        placeholder="URL"
                        value={value}
                        onChange={(e) => updateSocialLink(key, key, e.target.value)}
                        className="flex-2"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeSocialLink(key)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <Button type="button" variant="outline" onClick={addSocialLink}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Social Link
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="navigation" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Navigation Links</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {config.navLinks.map((link, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Input
                        placeholder="Link Name"
                        value={link.name}
                        onChange={(e) => updateNavLink(index, "name", e.target.value)}
                        className="flex-1"
                      />
                      <Input
                        placeholder="Link URL"
                        value={link.href}
                        onChange={(e) => updateNavLink(index, "href", e.target.value)}
                        className="flex-2"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeNavLink(index)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <Button type="button" variant="outline" onClick={addNavLink}>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Navigation Link
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="ai" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>AI Agent Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="aiAgentVisible"
                      checked={config.aiAgentVisible}
                      onCheckedChange={(checked) => setConfig((prev) => ({ ...prev!, aiAgentVisible: checked }))}
                    />
                    <Label htmlFor="aiAgentVisible">Enable AI Agent</Label>
                  </div>

                  <div>
                    <Label htmlFor="aiAgentGreeting">Greeting Message *</Label>
                    <Textarea
                      id="aiAgentGreeting"
                      value={config.aiAgentGreeting}
                      onChange={(e) => setConfig((prev) => ({ ...prev!, aiAgentGreeting: e.target.value }))}
                      placeholder="Hi! How can I help you today?"
                      rows={3}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="aiAgentPersona">AI Persona *</Label>
                    <Textarea
                      id="aiAgentPersona"
                      value={config.aiAgentPersona}
                      onChange={(e) => setConfig((prev) => ({ ...prev!, aiAgentPersona: e.target.value }))}
                      placeholder="Describe the AI agent's personality and role..."
                      rows={4}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="aiAgentKnowledgeBase">Knowledge Base</Label>
                    <Textarea
                      id="aiAgentKnowledgeBase"
                      value={config.aiAgentKnowledgeBase}
                      onChange={(e) => setConfig((prev) => ({ ...prev!, aiAgentKnowledgeBase: e.target.value }))}
                      placeholder="Additional knowledge for the AI agent..."
                      rows={8}
                    />
                  </div>

                  <div>
                    <Label htmlFor="aiAgentIconUrl">AI Agent Icon URL</Label>
                    <Input
                      id="aiAgentIconUrl"
                      value={config.aiAgentIconUrl || ""}
                      onChange={(e) => setConfig((prev) => ({ ...prev!, aiAgentIconUrl: e.target.value }))}
                      placeholder="https://example.com/ai-icon.png"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </form>
      </div>
    </AdminLayout>
  )
}
