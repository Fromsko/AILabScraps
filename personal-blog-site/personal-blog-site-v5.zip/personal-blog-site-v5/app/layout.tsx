import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AIChatWidget } from "@/components/ai-chat-widget"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: {
    default: "Personal Blog - Insights & Stories",
    template: "%s | Personal Blog",
  },
  description:
    "A personal blog sharing insights, stories, and experiences in technology, life, and everything in between.",
  keywords: ["blog", "personal", "technology", "insights", "stories"],
  authors: [{ name: "Blog Author" }],
  creator: "Blog Author",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://your-blog-domain.com",
    title: "Personal Blog - Insights & Stories",
    description:
      "A personal blog sharing insights, stories, and experiences in technology, life, and everything in between.",
    siteName: "Personal Blog",
  },
  twitter: {
    card: "summary_large_image",
    title: "Personal Blog - Insights & Stories",
    description:
      "A personal blog sharing insights, stories, and experiences in technology, life, and everything in between.",
    creator: "@yourusername",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <div className="min-h-screen flex flex-col">
            <Navbar />
            <main className="flex-grow">{children}</main>
            <Footer />
          </div>
          <AIChatWidget />
        </ThemeProvider>
      </body>
    </html>
  )
}
