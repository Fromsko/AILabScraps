import { FileSystemStorage } from "../file-system-storage"
import type { ICategoryRepository, Category } from "../../interfaces/data-access"

export class CategoryRepository extends FileSystemStorage<Category> implements ICategoryRepository {
  constructor() {
    super(process.cwd() + "/data", "categories.json")
  }

  async findBySlug(slug: string): Promise<Category | null> {
    const categories = await this.readData()
    return categories.find((category) => category.slug === slug) || null
  }

  async findAll(): Promise<Category[]> {
    const categories = await this.readData()
    return categories.sort((a, b) => a.name.localeCompare(b.name))
  }

  async create(category: Omit<Category, "id" | "createdAt" | "updatedAt">): Promise<Category> {
    const now = new Date()
    const newCategory: Category = {
      ...category,
      id: "",
      createdAt: now,
      updatedAt: now,
    }

    return super.create(newCategory)
  }

  async update(id: string, updates: Partial<Category>): Promise<Category> {
    const updateData = {
      ...updates,
      updatedAt: new Date(),
    }

    return super.update(id, updateData)
  }
}
