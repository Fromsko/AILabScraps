import fs from "fs/promises"
import path from "path"
import { v4 as uuidv4 } from "uuid"

// 文件系统存储基类
export class FileSystemStorage<T extends { id: string }> {
  private dataDir: string
  private fileName: string

  constructor(dataDir: string, fileName: string) {
    this.dataDir = dataDir
    this.fileName = fileName
  }

  private get filePath(): string {
    return path.join(this.dataDir, this.fileName)
  }

  async ensureDataDir(): Promise<void> {
    try {
      await fs.access(this.dataDir)
    } catch {
      await fs.mkdir(this.dataDir, { recursive: true })
    }
  }

  async readData(): Promise<T[]> {
    await this.ensureDataDir()

    try {
      const data = await fs.readFile(this.filePath, "utf-8")
      return JSON.parse(data, (key, value) => {
        // 自动转换日期字符串
        if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/.test(value)) {
          return new Date(value)
        }
        return value
      })
    } catch (error) {
      if ((error as any).code === "ENOENT") {
        return []
      }
      throw error
    }
  }

  async writeData(data: T[]): Promise<void> {
    await this.ensureDataDir()
    await fs.writeFile(this.filePath, JSON.stringify(data, null, 2), "utf-8")
  }

  async findAll(): Promise<T[]> {
    return this.readData()
  }

  async findById(id: string): Promise<T | null> {
    const data = await this.readData()
    return data.find((item) => item.id === id) || null
  }

  async create(item: Omit<T, "id">): Promise<T> {
    const data = await this.readData()
    const newItem = {
      ...item,
      id: uuidv4(),
    } as T

    data.push(newItem)
    await this.writeData(data)
    return newItem
  }

  async update(id: string, updates: Partial<T>): Promise<T> {
    const data = await this.readData()
    const index = data.findIndex((item) => item.id === id)

    if (index === -1) {
      throw new Error(`Item with id ${id} not found`)
    }

    data[index] = { ...data[index], ...updates }
    await this.writeData(data)
    return data[index]
  }

  async delete(id: string): Promise<void> {
    const data = await this.readData()
    const filteredData = data.filter((item) => item.id !== id)

    if (filteredData.length === data.length) {
      throw new Error(`Item with id ${id} not found`)
    }

    await this.writeData(filteredData)
  }
}
