"use client"

import { getDataAccess } from "./data/data-access-factory"
import { hashPassword } from "./auth"

export async function seedData() {
  try {
    console.log("🌱 Initializing data...")

    const dataAccess = getDataAccess()

    // 创建管理员用户
    try {
      const existingAdmin = await dataAccess.adminUsers.findByUsername(process.env.ADMIN_USERNAME || "admin")
      if (!existingAdmin) {
        const hashedPassword = await hashPassword(process.env.ADMIN_PASSWORD || "admin123")
        await dataAccess.adminUsers.create({
          username: process.env.ADMIN_USERNAME || "admin",
          passwordHash: hashedPassword,
          role: "admin",
        })
        console.log("✅ Admin user created")
      }
    } catch (error) {
      console.log("ℹ️ Admin user already exists")
    }

    // 创建示例分类
    const categories = [
      { name: "Web Development", slug: "web-development", color: "#3B82F6", icon: "💻" },
      { name: "React", slug: "react", color: "#61DAFB", icon: "⚛️" },
      { name: "Next.js", slug: "nextjs", color: "#000000", icon: "▲" },
      { name: "Career", slug: "career", color: "#10B981", icon: "🚀" },
      { name: "Tutorial", slug: "tutorial", color: "#F59E0B", icon: "📚" },
    ]

    const createdCategories = []
    for (const category of categories) {
      try {
        const existing = await dataAccess.categories.findBySlug(category.slug)
        if (!existing) {
          const created = await dataAccess.categories.create(category)
          createdCategories.push(created)
        } else {
          createdCategories.push(existing)
        }
      } catch (error) {
        console.log(`ℹ️ Category ${category.name} already exists`)
      }
    }
    console.log("✅ Categories created")

    // 创建示例标签
    const tags = [
      { name: "JavaScript", slug: "javascript" },
      { name: "TypeScript", slug: "typescript" },
      { name: "CSS", slug: "css" },
      { name: "Frontend", slug: "frontend" },
      { name: "Backend", slug: "backend" },
      { name: "Best Practices", slug: "best-practices" },
      { name: "Performance", slug: "performance" },
      { name: "Architecture", slug: "architecture" },
    ]

    const createdTags = []
    for (const tag of tags) {
      try {
        const existing = await dataAccess.tags.findBySlug(tag.slug)
        if (!existing) {
          const created = await dataAccess.tags.create(tag)
          createdTags.push(created)
        } else {
          createdTags.push(existing)
        }
      } catch (error) {
        console.log(`ℹ️ Tag ${tag.name} already exists`)
      }
    }
    console.log("✅ Tags created")

    // 创建示例文章
    await createSamplePosts(createdCategories, createdTags)

    console.log("🎉 Data initialization completed!")
  } catch (error) {
    console.error("❌ Data initialization failed:", error)
    throw error
  }
}

async function createSamplePosts(categories: any[], tags: any[]) {
  const dataAccess = getDataAccess()

  const samplePosts = [
    {
      title: "Getting Started with Next.js: A Comprehensive Guide",
      slug: "getting-started-with-nextjs",
      content: `# Getting Started with Next.js: A Comprehensive Guide

Next.js has revolutionized the way we build React applications. As a full-stack framework, it provides everything you need to build fast, SEO-friendly web applications with minimal configuration.

## What is Next.js?

Next.js is a React framework that gives you building blocks to create web applications. By framework, we mean Next.js handles the tooling and configuration needed for React, and provides additional structure, features, and optimizations for your application.

## Key Features

### 1. Server-Side Rendering (SSR)
Next.js can pre-render pages on the server, which improves performance and SEO. This means your pages are fully rendered before they reach the client.

### 2. Static Site Generation (SSG)
Generate static HTML at build time, perfect for content that doesn't change frequently. This provides the best performance possible.

### 3. API Routes
Build your backend API directly within your Next.js application. No need for a separate server!

### 4. File-based Routing
Create routes by simply adding files to the \`pages\` directory (or \`app\` directory in Next.js 13+).

## Getting Started

To create a new Next.js application, run:

\`\`\`bash
npx create-next-app@latest my-app
cd my-app
npm run dev
\`\`\`

This will create a new Next.js application with all the necessary dependencies and configuration.

## Conclusion

Next.js is an incredibly powerful framework that makes building React applications a joy. With its built-in optimizations, flexible rendering options, and excellent developer experience, it's no wonder it's become the go-to choice for many developers.

Whether you're building a simple blog, a complex e-commerce site, or anything in between, Next.js provides the tools and flexibility you need to succeed.

Happy coding!`,
      excerpt:
        "Learn the fundamentals of Next.js and how to build modern web applications with React's most popular framework.",
      featuredImage: "/placeholder.svg?height=400&width=600",
      publishDate: new Date("2024-01-15"),
      status: "published" as const,
      isFeatured: true,
      readingTime: 8,
      categoryIds: [
        categories.find((c) => c.slug === "nextjs")?.id,
        categories.find((c) => c.slug === "web-development")?.id,
        categories.find((c) => c.slug === "tutorial")?.id,
      ].filter(Boolean),
      tagIds: [
        tags.find((t) => t.slug === "javascript")?.id,
        tags.find((t) => t.slug === "frontend")?.id,
        tags.find((t) => t.slug === "best-practices")?.id,
      ].filter(Boolean),
    },
    {
      title: "Mastering Tailwind CSS: From Beginner to Pro",
      slug: "mastering-tailwind-css",
      content: `# Mastering Tailwind CSS: From Beginner to Pro

Tailwind CSS has transformed the way developers approach styling web applications. This utility-first CSS framework provides low-level utility classes that let you build custom designs without leaving your HTML.

## Why Tailwind CSS?

Traditional CSS frameworks like Bootstrap provide pre-designed components, but they often lead to websites that look similar. Tailwind takes a different approach by providing utility classes that you can combine to create unique designs.

### Benefits of Tailwind CSS

1. **Rapid Development**: Build interfaces quickly with utility classes
2. **Consistent Design**: Built-in design system ensures consistency
3. **Responsive by Default**: Mobile-first responsive design utilities
4. **Customizable**: Easily customize colors, spacing, and more
5. **Small Bundle Size**: Only includes the CSS you actually use

## Getting Started

Install Tailwind CSS in your project:

\`\`\`bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
\`\`\`

Configure your \`tailwind.config.js\`:

\`\`\`javascript
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
\`\`\`

## Core Concepts

### Utility Classes
Tailwind provides thousands of utility classes for styling:

\`\`\`html
<div class="bg-blue-500 text-white p-4 rounded-lg shadow-md">
  <h2 class="text-2xl font-bold mb-2">Card Title</h2>
  <p class="text-blue-100">Card description goes here.</p>
</div>
\`\`\`

### Responsive Design
Use responsive prefixes to apply styles at different breakpoints:

\`\`\`html
<div class="w-full md:w-1/2 lg:w-1/3">
  <!-- Full width on mobile, half on tablet, third on desktop -->
</div>
\`\`\`

## Conclusion

Tailwind CSS empowers developers to build beautiful, responsive designs quickly and efficiently. By embracing the utility-first approach, you can create unique designs while maintaining consistency and performance.

The key to mastering Tailwind is practice and understanding its design philosophy. Start with simple components and gradually work your way up to more complex layouts.

Remember, Tailwind is a tool to enhance your workflow, not replace your design skills. Use it to bring your creative visions to life!`,
      excerpt: "Discover how to leverage Tailwind CSS to build beautiful, responsive designs quickly and efficiently.",
      featuredImage: "/placeholder.svg?height=400&width=600",
      publishDate: new Date("2024-01-10"),
      status: "published" as const,
      isFeatured: true,
      readingTime: 12,
      categoryIds: [
        categories.find((c) => c.slug === "web-development")?.id,
        categories.find((c) => c.slug === "tutorial")?.id,
      ].filter(Boolean),
      tagIds: [
        tags.find((t) => t.slug === "css")?.id,
        tags.find((t) => t.slug === "frontend")?.id,
        tags.find((t) => t.slug === "best-practices")?.id,
      ].filter(Boolean),
    },
    {
      title: "Building Scalable React Applications: Architecture and Best Practices",
      slug: "building-scalable-react-applications",
      content: `# Building Scalable React Applications: Architecture and Best Practices

As React applications grow in complexity, maintaining code quality, performance, and developer productivity becomes increasingly challenging. This guide explores proven strategies for building scalable React applications that can evolve with your needs.

## What Makes an Application Scalable?

A scalable React application should:

- **Handle increased complexity** without becoming unmaintainable
- **Support team growth** with clear patterns and conventions
- **Maintain performance** as features are added
- **Enable code reuse** across different parts of the application
- **Facilitate testing** at all levels
- **Allow for easy refactoring** and feature updates

## Project Structure

A well-organized project structure is the foundation of scalability:

\`\`\`
src/
├── components/
│   ├── ui/           # Reusable UI components
│   ├── forms/        # Form-specific components
│   └── layout/       # Layout components
├── features/         # Feature-based modules
│   ├── auth/
│   ├── dashboard/
│   └── profile/
├── hooks/           # Custom hooks
├── services/        # API and external services
├── utils/           # Utility functions
├── types/           # TypeScript type definitions
├── contexts/        # React contexts
└── constants/       # Application constants
\`\`\`

### Feature-Based Architecture

Organize code by features rather than file types:

\`\`\`
features/
├── auth/
│   ├── components/
│   ├── hooks/
│   ├── services/
│   ├── types/
│   └── index.ts
└── dashboard/
    ├── components/
    ├── hooks/
    ├── services/
    ├── types/
    └── index.ts
\`\`\`

## Component Design Patterns

### Composition over Inheritance

Use composition to create flexible, reusable components:

\`\`\`tsx
// Good: Composable components
const Button = ({ children, className, ...props }) => (
  <button className={cn('btn', className)} {...props}>
    {children}
  </button>
)

const IconButton = ({ icon, children, ...props }) => (
  <Button {...props}>
    {icon && <span className="btn-icon">{icon}</span>}
    {children}
  </Button>
)
\`\`\`

## Performance Optimization

### Memoization

Use React.memo, useMemo, and useCallback strategically:

\`\`\`tsx
// Memoize expensive calculations
const ExpensiveComponent = ({ data }) => {
  const expensiveValue = useMemo(() => {
    return data.reduce((sum, item) => sum + item * item, 0)
  }, [data])
  
  return <div>Result: {expensiveValue}</div>
}
\`\`\`

## Conclusion

Building scalable React applications requires thoughtful architecture, consistent patterns, and a focus on maintainability. Key principles include:

1. **Organize by features**, not file types
2. **Favor composition** over complex prop interfaces
3. **Start with local state** and lift up when needed
4. **Extract reusable logic** into custom hooks
5. **Optimize performance** strategically
6. **Handle errors** gracefully
7. **Test at multiple levels**

Remember, scalability is not just about handling more users or data—it's about building applications that can evolve with changing requirements while maintaining code quality and developer productivity.`,
      excerpt:
        "Learn how to architect React applications that can grow with your team and requirements while maintaining code quality and performance.",
      featuredImage: "/placeholder.svg?height=400&width=600",
      publishDate: new Date("2024-01-05"),
      status: "published" as const,
      isFeatured: true,
      readingTime: 15,
      categoryIds: [
        categories.find((c) => c.slug === "react")?.id,
        categories.find((c) => c.slug === "web-development")?.id,
      ].filter(Boolean),
      tagIds: [
        tags.find((t) => t.slug === "javascript")?.id,
        tags.find((t) => t.slug === "typescript")?.id,
        tags.find((t) => t.slug === "architecture")?.id,
        tags.find((t) => t.slug === "best-practices")?.id,
      ].filter(Boolean),
    },
    {
      title: "The Future of Web Development: Trends to Watch in 2024",
      slug: "future-of-web-development-2024",
      content: `# The Future of Web Development: Trends to Watch in 2024

The web development landscape is constantly evolving, with new technologies, frameworks, and methodologies emerging regularly. As we progress through 2024, several key trends are shaping the future of how we build and deploy web applications.

## 1. AI-Powered Development Tools

Artificial Intelligence is revolutionizing the development process:

- **Code Generation**: Tools like GitHub Copilot and ChatGPT are helping developers write code faster
- **Automated Testing**: AI can generate comprehensive test suites
- **Bug Detection**: Machine learning models can identify potential issues before they reach production
- **Design to Code**: Converting designs directly to functional code

## 2. Edge Computing and CDNs

The shift towards edge computing is accelerating:

- **Faster Performance**: Content served from locations closer to users
- **Reduced Latency**: Critical for real-time applications
- **Better User Experience**: Especially important for mobile users
- **Cost Optimization**: More efficient resource utilization

## 3. WebAssembly (WASM) Adoption

WebAssembly is gaining traction for performance-critical applications:

- **Near-Native Performance**: Run compiled code in the browser
- **Language Flexibility**: Use languages like Rust, C++, and Go
- **Gaming and Graphics**: Complex applications in the browser
- **Legacy Code Migration**: Bring existing applications to the web

## 4. Micro-Frontends Architecture

Breaking down monolithic frontends:

- **Team Independence**: Different teams can work on different parts
- **Technology Diversity**: Use different frameworks for different features
- **Scalability**: Easier to scale development teams
- **Deployment Flexibility**: Deploy parts of the application independently

## 5. Progressive Web Apps (PWAs) Evolution

PWAs continue to bridge the gap between web and native:

- **Improved Capabilities**: Better access to device features
- **App Store Distribution**: PWAs can now be distributed through app stores
- **Offline-First Design**: Better handling of network connectivity issues
- **Push Notifications**: Enhanced user engagement

## 6. Serverless and JAMstack

The serverless revolution continues:

- **Reduced Infrastructure Management**: Focus on code, not servers
- **Cost Efficiency**: Pay only for what you use
- **Automatic Scaling**: Handle traffic spikes automatically
- **Better Developer Experience**: Faster deployment and iteration

## 7. Web3 and Blockchain Integration

Decentralized web technologies are maturing:

- **DApps Development**: Decentralized applications
- **NFT Marketplaces**: Digital asset platforms
- **Cryptocurrency Integration**: Payment systems
- **Identity Management**: Decentralized authentication

## 8. Enhanced Developer Experience

Tools and workflows are becoming more sophisticated:

- **Hot Module Replacement**: Instant feedback during development
- **Type Safety**: Better tooling for TypeScript and other typed languages
- **Visual Development**: Low-code/no-code solutions for developers
- **Integrated DevOps**: Seamless CI/CD pipelines

## 9. Sustainability and Green Computing

Environmental consciousness in web development:

- **Performance Optimization**: Reducing energy consumption
- **Efficient Hosting**: Green hosting providers
- **Minimal JavaScript**: Reducing bundle sizes
- **Sustainable Design**: Considering environmental impact in design decisions

## 10. Enhanced Security Measures

Security remains a top priority:

- **Zero Trust Architecture**: Never trust, always verify
- **Advanced Authentication**: Biometric and multi-factor authentication
- **Privacy by Design**: Building privacy into applications from the start
- **Automated Security Testing**: Continuous security monitoring

## Preparing for the Future

To stay ahead in this rapidly evolving landscape:

1. **Continuous Learning**: Stay updated with new technologies and trends
2. **Experiment Early**: Try new tools and frameworks in side projects
3. **Focus on Fundamentals**: Strong basics will help you adapt to new technologies
4. **Community Engagement**: Participate in developer communities and conferences
5. **User-Centric Approach**: Always prioritize user experience and accessibility

## Conclusion

The future of web development is exciting and full of opportunities. While new technologies and trends emerge constantly, the core principles of building great user experiences, writing maintainable code, and solving real problems remain unchanged.

As developers, our role is to evaluate these trends critically, adopt what makes sense for our projects and teams, and always keep learning. The web platform continues to evolve, and those who embrace change while maintaining a solid foundation will thrive in this dynamic environment.

The key is not to chase every new trend, but to understand the problems they solve and make informed decisions about when and how to adopt them. Focus on building great products that serve your users well, and the technology choices will follow naturally.`,
      excerpt:
        "Explore the key trends and technologies that are shaping the future of web development in 2024 and beyond.",
      featuredImage: "/placeholder.svg?height=400&width=600",
      publishDate: new Date("2024-01-20"),
      status: "published" as const,
      isFeatured: false,
      readingTime: 10,
      categoryIds: [
        categories.find((c) => c.slug === "web-development")?.id,
        categories.find((c) => c.slug === "career")?.id,
      ].filter(Boolean),
      tagIds: [
        tags.find((t) => t.slug === "javascript")?.id,
        tags.find((t) => t.slug === "frontend")?.id,
        tags.find((t) => t.slug === "performance")?.id,
      ].filter(Boolean),
    },
    {
      title: "My Journey from Junior to Senior Developer: Lessons Learned",
      slug: "junior-to-senior-developer-journey",
      content: `# My Journey from Junior to Senior Developer: Lessons Learned

Reflecting on my career progression from a junior developer to a senior role, I want to share the key lessons, challenges, and insights that shaped my journey. This post is for anyone looking to advance their career in software development.

## The Early Days: Junior Developer Struggles

When I started as a junior developer, I faced several challenges:

### Imposter Syndrome
- Feeling like I didn't belong
- Constantly comparing myself to senior developers
- Fear of asking "stupid" questions

### Technical Overwhelm
- Too many technologies to learn
- Difficulty understanding complex codebases
- Struggling with debugging and problem-solving

### Communication Barriers
- Difficulty explaining technical concepts
- Hesitation to participate in meetings
- Unclear about requirements and expectations

## The Growth Phase: Mid-Level Developer

As I gained experience, several things started to change:

### Technical Confidence
- Better understanding of fundamental concepts
- Ability to work independently on features
- Improved debugging and problem-solving skills

### Broader Perspective
- Understanding of software architecture
- Awareness of business requirements
- Consideration of user experience

### Mentoring Others
- Helping junior developers
- Code reviews and knowledge sharing
- Leading small projects

## Senior Developer: Beyond Just Coding

Becoming a senior developer involved developing skills beyond technical expertise:

### System Design and Architecture
- Designing scalable and maintainable systems
- Making technology decisions
- Understanding trade-offs and constraints

### Leadership and Communication
- Mentoring team members
- Facilitating technical discussions
- Communicating with stakeholders

### Business Acumen
- Understanding product requirements
- Considering cost and time constraints
- Aligning technical decisions with business goals

## Key Lessons Learned

### 1. Focus on Fundamentals

Strong fundamentals are more valuable than knowing the latest framework:

- **Data Structures and Algorithms**: Essential for problem-solving
- **Design Patterns**: Reusable solutions to common problems
- **System Design**: Understanding how systems work together
- **Testing**: Writing reliable and maintainable code

### 2. Embrace Continuous Learning

The tech industry evolves rapidly:

- **Stay Curious**: Always be willing to learn new things
- **Read Code**: Study well-written open-source projects
- **Attend Conferences**: Learn from industry experts
- **Build Side Projects**: Experiment with new technologies

### 3. Develop Soft Skills

Technical skills alone aren't enough:

- **Communication**: Explain complex concepts clearly
- **Collaboration**: Work effectively with team members
- **Problem-Solving**: Break down complex problems
- **Time Management**: Prioritize tasks effectively

### 4. Understand the Business

Great developers understand the business context:

- **User Needs**: Build features that solve real problems
- **Business Constraints**: Work within budget and time limits
- **Product Strategy**: Align technical decisions with business goals
- **Market Awareness**: Understand the competitive landscape

### 5. Quality Over Quantity

Focus on writing quality code:

- **Readability**: Code is read more often than it's written
- **Maintainability**: Consider future developers (including yourself)
- **Testing**: Invest in automated testing
- **Documentation**: Document important decisions and processes

### 6. Learn from Failures

Mistakes are learning opportunities:

- **Post-Mortems**: Analyze what went wrong and why
- **Feedback**: Seek feedback from peers and mentors
- **Iteration**: Continuously improve your approach
- **Resilience**: Bounce back from setbacks

## Advice for Aspiring Senior Developers

### For Junior Developers

1. **Ask Questions**: Don't be afraid to ask for help
2. **Take Initiative**: Volunteer for challenging tasks
3. **Learn from Code Reviews**: Treat feedback as learning opportunities
4. **Build Things**: Create projects outside of work
5. **Find Mentors**: Learn from experienced developers

### For Mid-Level Developers

1. **Mentor Others**: Teaching reinforces your own learning
2. **Lead Projects**: Take ownership of features or initiatives
3. **Improve Processes**: Identify and solve team inefficiencies
4. **Expand Your Scope**: Learn about adjacent areas (design, product, etc.)
5. **Build Your Network**: Connect with other professionals

## The Ongoing Journey

Becoming a senior developer isn't a destination—it's an ongoing journey:

- **Stay Humble**: There's always more to learn
- **Give Back**: Help others on their journey
- **Stay Current**: Keep up with industry trends
- **Maintain Balance**: Avoid burnout and maintain work-life balance

## Conclusion

The journey from junior to senior developer is challenging but rewarding. It requires not just technical growth, but also development of soft skills, business understanding, and leadership abilities.

Remember that everyone's journey is different. Focus on continuous improvement, be patient with yourself, and celebrate the small wins along the way. The most important thing is to keep learning, growing, and helping others do the same.

The tech industry needs more senior developers who can not only write great code but also mentor others, make sound technical decisions, and contribute to building great products. I hope my journey and lessons learned can help you on your own path to becoming a senior developer.

Good luck on your journey!`,
      excerpt:
        "A personal reflection on the journey from junior to senior developer, sharing key lessons, challenges, and advice for career growth.",
      featuredImage: "/placeholder.svg?height=400&width=600",
      publishDate: new Date("2024-01-25"),
      status: "published" as const,
      isFeatured: false,
      readingTime: 12,
      categoryIds: [categories.find((c) => c.slug === "career")?.id].filter(Boolean),
      tagIds: [tags.find((t) => t.slug === "best-practices")?.id].filter(Boolean),
    },
  ]

  for (const post of samplePosts) {
    try {
      const existing = await dataAccess.posts.findBySlug(post.slug)
      if (!existing) {
        await dataAccess.posts.create({
          ...post,
          authorName: "Blog Author",
        })
        console.log(`✅ Created sample post: ${post.title}`)
      }
    } catch (error) {
      console.log(`ℹ️ Post ${post.title} already exists or failed to create`)
    }
  }
}

// 如果直接运行此脚本
if (require.main === module) {
  seedData()
    .then(() => {
      console.log("Seeding completed")
      process.exit(0)
    })
    .catch((error) => {
      console.error("Seeding failed:", error)
      process.exit(1)
    })
}
