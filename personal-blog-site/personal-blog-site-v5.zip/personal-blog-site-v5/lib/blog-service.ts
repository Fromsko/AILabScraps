import { getDataAccess } from "./data/data-access-factory"
import type { BlogPost } from "./interfaces/data-access"

export interface BlogPostWithRelations extends BlogPost {
  categories: Array<{
    id: string
    name: string
    slug: string
    color?: string
    icon?: string
  }>
  tags: Array<{
    id: string
    name: string
    slug: string
  }>
}

export async function getAllPublishedPosts(
  page = 1,
  limit = 6,
): Promise<{
  posts: BlogPostWithRelations[]
  totalPages: number
  currentPage: number
}> {
  const dataAccess = getDataAccess()
  const result = await dataAccess.posts.findAll(page, limit, "published")

  // 获取分类和标签信息
  const [categories, tags] = await Promise.all([dataAccess.categories.findAll(), dataAccess.tags.findAll()])

  const postsWithRelations = result.items.map((post) => ({
    ...post,
    categories: post.categoryIds.map((id) => categories.find((c) => c.id === id)).filter(Boolean) as any[],
    tags: post.tagIds.map((id) => tags.find((t) => t.id === id)).filter(Boolean) as any[],
  }))

  return {
    posts: postsWithRelations,
    totalPages: result.totalPages,
    currentPage: result.currentPage,
  }
}

export async function getPostBySlug(slug: string): Promise<BlogPostWithRelations | null> {
  const dataAccess = getDataAccess()
  const post = await dataAccess.posts.findBySlug(slug)

  if (!post || post.status !== "published") return null

  // 获取分类和标签信息
  const [categories, tags] = await Promise.all([dataAccess.categories.findAll(), dataAccess.tags.findAll()])

  return {
    ...post,
    categories: post.categoryIds.map((id) => categories.find((c) => c.id === id)).filter(Boolean) as any[],
    tags: post.tagIds.map((id) => tags.find((t) => t.id === id)).filter(Boolean) as any[],
  }
}

export async function getFeaturedPosts(limit = 3): Promise<BlogPostWithRelations[]> {
  const dataAccess = getDataAccess()
  const posts = await dataAccess.posts.findFeatured(limit)

  // 获取分类和标签信息
  const [categories, tags] = await Promise.all([dataAccess.categories.findAll(), dataAccess.tags.findAll()])

  return posts.map((post) => ({
    ...post,
    categories: post.categoryIds.map((id) => categories.find((c) => c.id === id)).filter(Boolean) as any[],
    tags: post.tagIds.map((id) => tags.find((t) => t.id === id)).filter(Boolean) as any[],
  }))
}

export async function getRelatedPosts(postId: string, limit = 3): Promise<BlogPostWithRelations[]> {
  const dataAccess = getDataAccess()
  const posts = await dataAccess.posts.findRelated(postId, limit)

  // 获取分类和标签信息
  const [categories, tags] = await Promise.all([dataAccess.categories.findAll(), dataAccess.tags.findAll()])

  return posts.map((post) => ({
    ...post,
    categories: post.categoryIds.map((id) => categories.find((c) => c.id === id)).filter(Boolean) as any[],
    tags: post.tagIds.map((id) => tags.find((t) => t.id === id)).filter(Boolean) as any[],
  }))
}

export async function searchPosts(
  query: string,
  page = 1,
  limit = 6,
): Promise<{
  posts: BlogPostWithRelations[]
  totalPages: number
  currentPage: number
}> {
  const dataAccess = getDataAccess()
  const result = await dataAccess.posts.search(query, page, limit)

  // 获取分类和标签信息
  const [categories, tags] = await Promise.all([dataAccess.categories.findAll(), dataAccess.tags.findAll()])

  const postsWithRelations = result.items.map((post) => ({
    ...post,
    categories: post.categoryIds.map((id) => categories.find((c) => c.id === id)).filter(Boolean) as any[],
    tags: post.tagIds.map((id) => tags.find((t) => t.id === id)).filter(Boolean) as any[],
  }))

  return {
    posts: postsWithRelations,
    totalPages: result.totalPages,
    currentPage: result.currentPage,
  }
}
